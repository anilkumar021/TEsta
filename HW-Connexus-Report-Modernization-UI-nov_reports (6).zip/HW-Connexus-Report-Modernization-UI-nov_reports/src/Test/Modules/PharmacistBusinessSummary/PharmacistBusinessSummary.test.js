import React from 'react';
import { shallow } from 'enzyme';
import { mockSuccess, mockFailure } from '../../util';
import Wrapper, {
  PharmacistBusinessSummary,
} from '../../../Modules/PharmacistBusinessSummary/PharmacistBusinessSummary';

describe('PharmacistBusinessSummary', () => {
  const data = {
    storeId: 5545,
    date: '2020-08-10T23:28:56.782Z',
    appName: 'Connexus Pharmacy System',
    store: 'Sams Pharmacy10-5545',
    reportName: 'Pharmacist Store Business Summary Report',
    details: 'Daily Summary',
    summary: {
      salesperformance: {
        label: 'Sales Performance',
        id: 'salesPerformance',
        header: [
          {
            label: 'Sales Performance',
            id: 'salesPerform',
            type: null,
          },
          {
            label: 'TY',
            id: 'ty',
            type: 'Today',
          },
          {
            label: 'Last Year',
            id: 'lastYear',
            type: 'Today',
          },
          {
            label: '%INC',
            id: 'incTdy',
            type: 'Today',
          },
          {
            label: 'WTD',
            id: 'wtd',
            type: 'Total',
          },
          {
            label: '%INC',
            id: 'incTot1',
            type: 'Total',
          },
          {
            label: 'MTD',
            id: 'mtd',
            type: 'Total',
          },
          {
            label: '%INC',
            id: 'incTot2',
            type: 'Total',
          },
        ],
        data: [
          {
            salesPerform: 'Div 10',
            ty: '0.00',
            lastYear: '0.00',
            incTdy: '0',
            wtd: '0.00',
            incTot1: '0',
            mtd: '0.00',
            incTot2: '0.00',
          },
          {
            salesPerform: '-Dept 27',
            ty: '0.00',
            lastYear: '0.00',
            incTdy: '0.00',
            wtd: '0.00',
            incTot1: '0.00',
            mtd: '0.00',
            incTot2: '0.00',
          },
        ],
        pos: {
          label: 'POS',
          description: 'Long/Short',
          value: null,
        },
      },
    },
  };

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(
      <PharmacistBusinessSummary location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(
      <PharmacistBusinessSummary location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <PharmacistBusinessSummary location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <PharmacistBusinessSummary location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(
      <PharmacistBusinessSummary location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});
