import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  RxActivityReport,
} from '../../../../Modules/RxReports/RxActivityReport/RxActivityReport';
import { mockSuccess, mockFailure } from '../../../util';

describe('RxActivityReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    mockSuccess({ data: {} });
    const component = shallow(<RxActivityReport location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual({});
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<RxActivityReport location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toBe('error');
  });

  it('should render correctly', () => {
    const component = shallow(<RxActivityReport location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<RxActivityReport location={{}} />);
    const instance = component.instance();
    instance.setState({ data: {}, loading: false });
  });
});
