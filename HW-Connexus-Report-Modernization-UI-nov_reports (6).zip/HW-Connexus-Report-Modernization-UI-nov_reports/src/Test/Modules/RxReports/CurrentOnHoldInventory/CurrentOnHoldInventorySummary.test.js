import React from 'react';
import { shallow } from 'enzyme';
import { mockSuccess, mockFailure } from '../../../util';
import Wrapper, {
  CurrentOnHoldInventorySummary,
} from '../../../../Modules/RxReports/CurrentOnHoldInventory/CurrentOnHoldInventorySummary';
import * as data from '../../../../../public/current-on-hold-inventory-report-summary.json';

describe('CurrentOnHoldInventorySummaryTable', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventorySummary location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventorySummary location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventorySummary location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(
      <CurrentOnHoldInventorySummary location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(
      <CurrentOnHoldInventorySummary location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
