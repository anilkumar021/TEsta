import React from 'react';
import { shallow } from 'enzyme';
import * as data from '../../../../../public/current-on-hold-inventory-report-summary.json';
import { CurrentOnHoldInventorySummaryTable } from '../../../../Modules/RxReports/CurrentOnHoldInventory/CurrentOnHoldInventorySummaryTable';

describe('CurrentOnHoldInventorySummaryTable Test', () => {
  it('should render correctly', () => {
    shallow(
      <CurrentOnHoldInventorySummaryTable data={[]} header={[]} />,
    );
  });

  it('should render correctly', () => {
    shallow(
      <CurrentOnHoldInventorySummaryTable
        data={data.data}
        header={data.headers}
      />,
    );
  });
});
