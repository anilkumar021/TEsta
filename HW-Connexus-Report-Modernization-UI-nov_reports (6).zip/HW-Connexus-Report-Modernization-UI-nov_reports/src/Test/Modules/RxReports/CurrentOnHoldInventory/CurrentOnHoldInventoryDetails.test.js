import React from 'react';
import { shallow } from 'enzyme';
import { mockSuccess, mockFailure } from '../../../util';
import * as data from '../../../../../public/current-on-hold-inventory-details.json';
import Wrapper, {
  CurrentOnHoldInventoryDetails,
} from '../../../../Modules/RxReports/CurrentOnHoldInventoryDetails/CurrentOnHoldInventoryDetails';

describe('CurrentOnHoldInventoryDetails', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventoryDetails location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventoryDetails location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(
      <CurrentOnHoldInventoryDetails location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(
      <CurrentOnHoldInventoryDetails location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(
      <CurrentOnHoldInventoryDetails location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
