import React from 'react';
import { shallow } from 'enzyme';
import WillCallBinMain from '../../../../Modules/RxReports/WillCallBin/WillCallBinMain';
import { mockSuccess, mockFailure } from '../../../util';
import * as data from '../../../../../public/will-call-bin.json';
import * as testData from './testData.json';

describe('WillCallBinMain', () => {
  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(<WillCallBinMain location={{}} />);
    const instance = component.instance();
    expect(instance.state.data.data).toEqual(testData.data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<WillCallBinMain location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    const component = shallow(<WillCallBinMain location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<WillCallBinMain location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });
});
