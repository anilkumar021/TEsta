import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  WillCallBinSummary,
} from '../../../../Modules/RxReports/WillCallBin/WillCallBinSummary';
import * as data from '../../../../../public/will-call-bin.json';

const state = {
  data,
  loading: true,
  error: null,
  isSummaryReport: true,
  footerData: {},
  summaryTableData: [],
  notes: {},
};

describe('WillCallBinSummary', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<WillCallBinSummary state={state} />);
    component.instance();
  });
});
