import React from 'react';
import { shallow } from 'enzyme';
import WillCallBinDetailedTable from '../../../../Modules/RxReports/WillCallBin/WillCallBinDetailedTable';
import * as data from '../../../../../public/will-call-bin.json';

describe('WillCallBinDetailedTable', () => {
  it('should render correctly', () => {
    shallow(<WillCallBinDetailedTable data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    shallow(
      <WillCallBinDetailedTable
        data={data.data}
        header={data.header}
        footer={data.footer}
      />,
    );
  });
});
