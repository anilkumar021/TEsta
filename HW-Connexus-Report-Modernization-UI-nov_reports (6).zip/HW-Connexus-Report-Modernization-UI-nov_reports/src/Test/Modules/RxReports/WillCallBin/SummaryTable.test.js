import React from 'react';
import { shallow } from 'enzyme';
import SummaryTable from '../../../../Modules/RxReports/WillCallBin/SummaryTable';
import * as data from '../../../../../public/will-call-bin.json';

describe('WillCallBinSummary SummaryTable', () => {
  it('should render correctly', () => {
    shallow(<SummaryTable data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    shallow(
      <SummaryTable
        data={data.data}
        header={data.header}
        footer={data.footer}
      />,
    );
  });
});
