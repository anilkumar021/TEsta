import React from 'react';
import { shallow } from 'enzyme';
import UtilizationTable from '../../../../Modules/RxReports/AutoFillUtilization/UtilizationTable';
import * as data from '../../../../../public/autofill.json';

describe('UtilizationTable', () => {
  it('should render correctly', () => {
    shallow(<UtilizationTable data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    shallow(
      <UtilizationTable data={data.data} header={data.header} />,
    );
  });
});
