import React from 'react';
import { shallow } from 'enzyme';
import SummaryTable from '../../../../Modules/RxReports/AutoFillUtilization/SummaryTable';
import * as data from '../../../../../public/autofillsummary.json';

describe('SummaryTable', () => {
  it('should render correctly', () => {
    shallow(<SummaryTable data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    shallow(
      <SummaryTable
        data={data.data}
        header={data.header}
        totals={{}}
      />,
    );
  });
});
