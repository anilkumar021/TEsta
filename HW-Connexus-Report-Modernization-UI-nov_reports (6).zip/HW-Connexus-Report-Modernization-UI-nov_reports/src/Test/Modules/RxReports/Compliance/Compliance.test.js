import React from 'react';
import { shallow } from 'enzyme';
// import mockAxios from 'axios';
import Wrapper, {
  Compliance,
} from '../../../../Modules/RxReports/Compliance/Compliance';
import { mockSuccess, mockFailure } from '../../../util';

const data = {
  date: "11/04/2020",
  reportName: "Compliance Report",
  store: "Sam's Pharmacy10-5561",
  storeId: 5545,
  appName: "Connexus Pharmacy System",
  complianceSummaryHeaderBO: {
    complianceIndex: "N",
    dateRange: "From : 09/09/2020 To 10/09/2020",
    drugName: "Cabergoline TAB",
    dueDate: "11/11/2020",
    includeDeceasedPatientsData: "true",
    nextFillDate: null,
    showPatientIndex: "Y",
    showPrescriberIndex: "N",
    header: [
      {
        "id": "fillDate",
        "label": "Last FillDate"
      },
      {
        "id": "rxNbr",
        "label": "RX #"
      },
      {
        "id": "drugName",
        "label": "DrugName"
      },
      {
        "id": "quantity",
        "label": "Qty"
      },
      {
        "id": "reFill",
        "label": "Refill Auth/ Remain"
      },
      {
        "id": "tp",
        "label": "T/P",
      },
      {
        "id": "pay",
        "label": "Patient Pay"
      }
    ]
  },
  data: [
    {
      "drugName": "Cabergoline 0.5MG TAB",
      "fillDate": "11/04/2020",
      "pay": "$4.00",
      "quantity": 20,
      "reFill": "3.0/2.0",
      "rxNbr": 6600251,
      "tp": "Cash"
    },
    {
      "drugName": "Cabergoline 0.6MG TAB",
      "fillDate": "11/05/2020",
      "pay": "$5.00",
      "quantity": 25,
      "reFill": "3.0/1.0",
      "rxNbr": 6600252,
      "tp": "Cash"
    }
  ]
};

describe('Compliance', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<Compliance location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<Compliance location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<Compliance location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(<Compliance location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<Compliance location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});