import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/RxReports/Compliance/Table';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render correctly', () => {
    const component = shallow(<Table data={[]} header={[]} />);
    const instance = component.instance();
    expect(instance.header("DrugName", "true")).toBe("Patient");
    expect(instance.header("Qty", "false")).toBe("");
    const data = {
      drugName: "drugName",
      quantity: "8"
    }
    expect(instance.body(data, "quantity", "false")).toBe("");
    const wrapper = shallow(instance.body(data, "drugName", "false"));
    expect(wrapper.text()).toBe("drugNameQty: 8");

  });

  it('should render correctly', () => {
    const header = [
      {
        label: 'Rx',
        id: 'Rx',
      },
      {
        label: 'PatientName',
        id: 'PatientName',
      },
      {
        label: 'FillDate',
        id: 'FillDate',
      },
      {
        label: 'Drug',
        id: 'Drug',
      },
      {
        label: 'Quantity',
        id: 'Quantity',
      },
      {
        label: 'DAW',
        id: 'DAW',
      },
      {
        label: 'UserId',
        id: 'UserId',
      },
      {
        label: 'Date/Time',
        id: 'Date/Time',
      },
    ];
    shallow(<Table data={[{}]} header={header} />);
  });
});
