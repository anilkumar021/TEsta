import React from 'react';
import { shallow } from 'enzyme';
import { mockSuccess, mockFailure } from '../../../../util';
import Wrapper, {
  CiiDigitalLogbook,
} from '../../../../../Modules/InventoryReports/CIIReports/CIIDigitalLogbook/CIIDigitalLogbook';
import * as data from '../../../../../../public/cii-digital-logbook.json';

describe('CiiDigitalLogbook', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<CiiDigitalLogbook location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<CiiDigitalLogbook location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<CiiDigitalLogbook location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});

it('should render correctly', () => {
  mockSuccess({ data });
  const component = shallow(<CiiDigitalLogbook location={{}} />);
  const instance = component.instance();
  expect(instance.state.data).toEqual(data);
});

it('should render correctly', () => {
  mockFailure('error');
  const component = shallow(<CiiDigitalLogbook location={{}} />);
  const instance = component.instance();
  expect(instance.state.error).toEqual('error');
});
