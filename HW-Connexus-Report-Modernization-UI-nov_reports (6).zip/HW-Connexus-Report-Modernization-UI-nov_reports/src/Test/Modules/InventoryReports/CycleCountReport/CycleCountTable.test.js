import React from 'react';
import { shallow } from 'enzyme';
import Table from '../../../../Modules/InventoryReports/CycleCountReport/CycleCountTable';

describe('CycleCountReportTable', () => {
  it('should render correctly', () => {
    shallow(<Table data={[]} header={[]} />);
  });

  it('should render result correctly', () => {
    const header = [
      {
        label: 'NDC',
        id: 'ndc',
      },
      {
        label: 'Drug Name',
        id: 'drugName',
      },
      {
        label: 'Dept',
        id: 'dept',
      },
      {
        label: 'Pack Size',
        id: 'packSize',
      },
      {
        label: 'Drug Schedule',
        id: 'drugSchedule',
      },
      {
        label: 'Create Date',
        id: 'createDate',
      },
      {
        label: 'Type',
        id: 'type',
      },
      {
        label: 'Enter Quantity',
        id: 'enterQuantity',
      },
      {
        label: 'Validate',
        id: 'validate',
      },
    ];
    const data = [
      {
        unique: 1,
        ndc: 51079093020,
        drugName: 'Acetaminophen',
        dept: 'General Medicine',
        packSize: 30,
        drugSchedule: '11/11/2021',
        createDate: '11/11/2020',
        type: 'Type 2',
        enterQuantity: '',
        validate: '',
      },
      {
        unique: 2,
        ndc: 64376064901,
        drugName: 'Bisoprolol',
        dept: 'Cardiology',
        packSize: 50,
        drugSchedule: '02/11/2021',
        createDate: '03/11/2020',
        type: 'Type 3',
        enterQuantity: '',
        validate: '',
      },
      {
        unique: 3,
        ndc: 45802043262,
        drugName: 'Corticosteroids',
        dept: 'Orthopaedic',
        packSize: 60,
        drugSchedule: '06/11/2021',
        createDate: '08/11/2020',
        type: 'Type 1',
        enterQuantity: '',
        validate: '',
      },
    ];
    shallow(<Table data={data} header={header} />);
  });
});
