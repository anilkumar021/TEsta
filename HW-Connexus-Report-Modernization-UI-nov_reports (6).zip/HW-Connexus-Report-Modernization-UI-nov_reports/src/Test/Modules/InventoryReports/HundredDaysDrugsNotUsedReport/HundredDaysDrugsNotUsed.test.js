import React from 'react';
import { shallow } from 'enzyme';
import { mockSuccess, mockFailure } from '../../../util';
import * as data from '../../../../../public/100-days-drugs-not-used.json';
import Wrapper, {
  HundredDaysDrugsNotUsed,
} from '../../../../Modules/InventoryReports/HundredDaysDrugsNotUsedReport/HundredDaysDrugsNotUsed';

describe('HundredDaysDrugsNotUsed', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <HundredDaysDrugsNotUsed location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <HundredDaysDrugsNotUsed location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(
      <HundredDaysDrugsNotUsed location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});

it('should render correctly', () => {
  mockSuccess({ data });
  const component = shallow(
    <HundredDaysDrugsNotUsed location={{}} />,
  );
  const instance = component.instance();
  expect(instance.state.data).toEqual(data);
});

it('should render correctly', () => {
  mockFailure('error');
  const component = shallow(
    <HundredDaysDrugsNotUsed location={{}} />,
  );
  const instance = component.instance();
  expect(instance.state.error).toEqual('error');
});
