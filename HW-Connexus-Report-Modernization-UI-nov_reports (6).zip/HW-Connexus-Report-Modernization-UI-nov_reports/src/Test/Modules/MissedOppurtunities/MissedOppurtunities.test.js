import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  MissedOppurtunitiesReport,
} from '../../../Modules/MissedOppurtunities/MissedOppurtunitiesReport';
import { mockSuccess, mockFailure } from '../../util';

describe('MissedOppurtunitiesReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(
      <MissedOppurtunitiesReport location={{}} />,
    );
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(
      <MissedOppurtunitiesReport location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data: { data: [{}, {}] } });
    const component = shallow(
      <MissedOppurtunitiesReport location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.data).toEqual({ data: [{}, {}] });
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(
      <MissedOppurtunitiesReport location={{}} />,
    );
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    const data = {
      data: [
        {
          rxNbr: 6600251,
          unique: 1,
          patient: 'ALRED,CONNIE',
          daw: 1300,
          drug: 'COREG 6.25MG TAB',
          ndc: 51079093020,
          qty: 30,
          mult: 2602,
          filled: '10/06/2020 11:45:00 AM',
          acq: 4.24,
          uc: 4.36,
          price: 4.36,
          gp: 1,
        },
        {
          rxNbr: 7600251,
          unique: 2,
          patient: 'ALRED,CONNIE',
          daw: 1300,
          drug: 'COREG 6.25MG TAB',
          ndc: 51079093020,
          qty: 30,
          mult: 2602,
          filled: '10/06/2020 11:45:00 AM',
          acq: 4.24,
          uc: 4.36,
          price: 4.36,
          gp: 2,
        },
      ],
      aggregates: {
        TotalMultiSourceCodeO: 0,
        TotalMultiSourceCodeY: 0,
        TotalMultiSourceCodeYAndO: 31,
        'TotalMultiSourceCodeOAndDAW-1': 0,
        'TotalMultiSourceCodeYAndLessDAW-1': 31,
        GenericSubdtitutionPercentOfMultiSourceCodeO: 100,
        GenericSubdtitutionPercentOfMultiSourceCodeOLessDAWCode1Transaction: 100,
      },
    };
    const component = shallow(
      <MissedOppurtunitiesReport location={{}} />,
    );
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});
