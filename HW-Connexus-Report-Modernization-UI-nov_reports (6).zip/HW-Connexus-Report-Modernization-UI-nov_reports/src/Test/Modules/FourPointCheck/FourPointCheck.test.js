import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  FourPointCheck,
} from '../../../Modules/FourPointCheck/FourPointCheck';
import { mockSuccess, mockFailure } from '../../util';

describe('FourPointCheck', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '2020-01-01T23:28:56.782Z',
          pharmacists: [
            {
              pharmacistName: 'Chinmoy Pradhan',
              data: [
                {
                  Rx: 881006,
                  PatientName: 'DISK,Orenge',
                  FillDate: '2020-01-01T23:28:56.782Z',
                  Drug: 'ADVANCE FORMULA CE TAB',
                  Quantity: 5,
                  DAW: 0,
                  UserId: '50',
                  'Date-Time': '2020-01-01T23:28:56.782Z',
                },
              ],
            },
          ],
        },
      ],
    };
    mockSuccess({ data });
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });
  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '2020-01-01T23:28:56.782Z',
          pharmacists: [
            {
              pharmacistName: 'Chinmoy Pradhan',
              data: [
                {
                  Rx: 881006,
                  PatientName: 'DISK,Orenge',
                  FillDate: '2020-01-01T23:28:56.782Z',
                  Drug: 'ADVANCE FORMULA CE TAB',
                  Quantity: 5,
                  DAW: 0,
                  UserId: '50',
                  'Date-Time': '2020-01-01T23:28:56.782Z',
                },
              ],
            },
          ],
        },
      ],
    };
    mockSuccess({ data });
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });

  it('should render correctly', () => {
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const data = {
      dates: [
        {
          date: '2020-01-01T23:28:56.782Z',
          pharmacists: [
            {
              pharmacistName: 'Chinmoy Pradhan',
              data: [
                {
                  Rx: 881006,
                  PatientName: 'DISK,Orenge',
                  FillDate: '2020-01-01T23:28:56.782Z',
                  Drug: 'ADVANCE FORMULA CE TAB',
                  Quantity: 5,
                  DAW: 0,
                  UserId: '50',
                  'Date-Time': '2020-01-01T23:28:56.782Z',
                },
              ],
            },
          ],
        },
      ],
    };
    const component = shallow(<FourPointCheck location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });
});
