import React from 'react';
import { shallow } from 'enzyme';
import Wrapper, {
  BaggingSummary,
} from '../../../Modules/Bagging/BaggingSummary';
import { mockSuccess, mockFailure } from '../../util';

const data = {
  storeId: 5545,
  reportDate: '11/04/2020',
  appName: 'Connexus Pharmacy System',
  store: 'Wal-Mart Pharmacy10-5533',
  reportName: 'BAGGING Summary REPORT',
  dateFrom: 'From : 08/10/2020',
  dateTo: 'To 11/10/2020',
  address: '5025 LOOP 410 NORTH 5025',
  detail: 'TRUTH OR CONSEQUENCE TRU COTulsa OK - 74008',
  header: [
    {
      id: 'userid',
      label: 'UserI',
    },
    {
      id: 'numberOrder',
      label: '# of Orders Bagge',
    },
    {
      id: 'numberRx',
      label: '# of RX Bagge',
    },
    {
      id: 'totalTime',
      label: 'Total Tim',
    },
    {
      id: 'avgTime',
      label: 'Avg time of bag orde',
    },
  ],
  data: [
    {
      unique: 'VN509PY',
      userid: 'VN509PY',
      numberOrder: 3,
      numberRx: 4,
      totalTime: '00:01:24',
      avgTime: '1:00:01:0',
    },
    {
      unique: 'VN5091Y',
      userid: 'VN5091Y',
      numberOrder: 2,
      numberRx: 3,
      totalTime: '00:01:24',
      avgTime: '1:00:01:0',
    },
  ],
};

describe('BaggingDetail', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingSummary location={{}} />);
    component.instance();
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingSummary location={{}} />);
    const instance = component.instance();
    instance.setState({ error: 'network error', loading: false });
  });

  it('should render correctly', () => {
    const component = shallow(<BaggingSummary location={{}} />);
    const instance = component.instance();
    instance.setState({ data, loading: false });
  });

  it('should render correctly', () => {
    mockSuccess({ data });
    const component = shallow(<BaggingSummary location={{}} />);
    const instance = component.instance();
    expect(instance.state.data).toEqual(data);
  });

  it('should render correctly', () => {
    mockFailure('error');
    const component = shallow(<BaggingSummary location={{}} />);
    const instance = component.instance();
    expect(instance.state.error).toEqual('error');
  });
});
