import React from 'react';
import { shallow } from 'enzyme';
import ErrorMessage from '../../../Modules/Common/ErrorMessage';

describe('ErrorMessage', () => {
  it('should render correctly', () => {
    shallow(<ErrorMessage />);
  });
});
