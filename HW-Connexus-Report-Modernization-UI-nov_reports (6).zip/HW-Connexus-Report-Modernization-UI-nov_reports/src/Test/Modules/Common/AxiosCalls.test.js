import moxios from 'moxios';
import { getApi, postApi } from '../../../Modules/Common/AxiosCalls';

describe('mocking axios requests', () => {
  beforeEach(() => {
    moxios.install();
  });

  afterEach(() => {
    moxios.uninstall();
  });

  it('specify response for a specific request', async (done) => {
    moxios.stubRequest('url', {
      status: 200,
      responseText: 'hello',
    });
    getApi(
      'url',
      {},
      {},
      () => {},
      () => {},
    );
    done();
  }, 30000);

  it('specify response for a specific request', async (done) => {
    moxios.stubRequest('url', {
      status: 400,
      responseText: 'error',
    });
    await getApi(
      'url',
      {},
      undefined,
      () => {},
      () => {},
    );
    done();
  }, 30000);

  it('specify response for a specific request', async (done) => {
    moxios.stubRequest('url', {
      status: 200,
      responseText: 'success',
    });
    await postApi(
      'url',
      undefined,
      undefined,
      () => {},
      () => {},
    );
    done();
  }, 30000);

  it('specify response for a specific request', async (done) => {
    moxios.stubRequest('url', {
      status: 400,
      responseText: 'error',
    });
    await postApi(
      'url',
      {},
      {},
      () => {},
      () => {},
    );
    done();
  }, 30000);
});
