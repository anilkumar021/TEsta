import React from 'react';
import ReactToPrint from 'react-to-print';
import { shallow } from 'enzyme';
import PrintReport from '../../../Modules/Common/PrintReport';

describe('RxReport', () => {
  it('should render correctly', () => {
    const Component = PrintReport(<div />);
    shallow(<Component />)
      .find(ReactToPrint)
      .props()
      .trigger();
    shallow(<Component />)
      .find(ReactToPrint)
      .props()
      .content();
  });
});
