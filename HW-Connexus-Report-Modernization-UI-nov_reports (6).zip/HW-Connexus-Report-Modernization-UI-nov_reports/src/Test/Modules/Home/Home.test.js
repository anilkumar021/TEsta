import React from 'react';
import { shallow } from 'enzyme';
import Wrapper from '../../../Modules/Home/Home';

describe('RxReport', () => {
  it('should render correctly', () => {
    shallow(<Wrapper />);
  });
});
