import * as Helper from '../Modules/Common/AxiosCalls';

Helper.getApi = jest.fn();

export const mockSuccess = (returnObj) => {
  jest.clearAllMocks();
  Helper.getApi.mockImplementation((url, params, header, success) => {
    success(returnObj);
  });
};

export const mockFailure = (returnObj) => {
  jest.clearAllMocks();
  Helper.getApi.mockImplementation(
    (url, params, header, success, failure) => {
      failure(returnObj);
    },
  );
};
