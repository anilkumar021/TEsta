import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import BaggingMain from './Modules/Bagging/BaggingMain';
import FourPointCheckReport from './Modules/FourPointCheck/FourPointCheck';
import Home from './Modules/Home/Home';
import MissedOppurtunitiesReport from './Modules/MissedOppurtunities/MissedOppurtunitiesReport';
import PharmacistActivity from './Modules/PharmacistActivity/PharmacistActivity';
import PharmacistBusinessSummary from './Modules/PharmacistBusinessSummary/PharmacistBusinessSummary';
import RemoteOrder from './Modules/RemoteOrder/RemoteOrder';
import AutoFillUtilizationMain from './Modules/RxReports/AutoFillUtilization/AutoFillUtilizationMain';
import CancelFill from './Modules/RxReports/CancelFill/CancelFill';
import CIIDigitalLogbook from './Modules/InventoryReports/CIIReports/CIIDigitalLogbook/CIIDigitalLogbook';
import CentralFillPerformance from './Modules/RxReports/CentralFillPerformance/CentralFillPerformance';
import Compliance from './Modules/RxReports/Compliance/Compliance';
import HundredDaysDrugsNotUsed from './Modules/InventoryReports/HundredDaysDrugsNotUsedReport/HundredDaysDrugsNotUsed';
import ControlledSubstancePickup from './Modules/RxReports/ControlledSubstancePickup/ControlledSubstancePickup';
import LeafletCoverSheet from './Modules/RxReports/LeafletCoverSheet/LeafletCoverSheet';
import OnHoldReport from './Modules/RxReports/OnHoldReport/OnHoldReport';
import PartialFill from './Modules/RxReports/PartialFill/PartialFill';
import RxReport from './Modules/RxReports/RxActivityReport/RxActivityReport';
import WaitForDrugOrder from './Modules/RxReports/WaitForDrugOrder/WaitForDrugOrder';
import TPReceivables from './Modules/TPReceivables/TPReceivables';
import WillCallBinMain from './Modules/RxReports/WillCallBin/WillCallBinMain';
import CycleCount from './Modules/InventoryReports/CycleCountReport/CycleCount';
import ReplenishmentUnAvailable from './Modules/InventoryReports/ReplenishmentReports/ReplenishmentUnAvailable/ReplenishmentUnAvailable';
import ReplenishmentAvailable from './Modules/InventoryReports/ReplenishmentReports/ReplenishmentAvailable/ReplenishmentAvailable';
import './App.css';
import RegulatoryPatientProfileReport from './Modules/RegulatoryPatientProfileReport/RegulatoryPatientProfileReport';
import  AutoFillCancellation  from './Modules/RxReports/AutoFillUtilization/AutoFillCancellation';
import CurrentOnHoldInventoryMain from './Modules/RxReports/CurrentOnHoldInventory/CurrentOnHoldInventoryMain';
import OrderCompletionPerformance from './Modules/DailyReports/OrderCompletionPerformance/OrderCompletionPerformance';

function App() {
  return (
    <Router>
      <Route exact path="/" component={Home} />
      <Route
        exact
        path="/auto-fill-utilization"
        component={AutoFillUtilizationMain}
      />
      <Route exact path="/on-hold" component={OnHoldReport} />
      <Route
        exact
        path="/drug-inventory-onhand"
        component={CurrentOnHoldInventoryMain}
      />
      <Route exact path="/rx-report" component={RxReport} />
      <Route
        exact
        path="/4-point-check-report"
        component={FourPointCheckReport}
      />
      <Route
        exact
        path="/pharmacy-activity"
        component={PharmacistActivity}
      />
      <Route
        exact
        path="/controlled-substance-pickup-report"
        component={ControlledSubstancePickup}
      />
      <Route
        exact
        path="/central-fill-performance-report"
        component={CentralFillPerformance}
      />
      <Route
        exact
        path="/pharmacy-business-summary"
        component={PharmacistBusinessSummary}
      />
      <Route
        exact
        path="/remote-order-review"
        component={RemoteOrder}
      />
      <Route
        exact
        path="/leaflet-cover-sheet-printed-by-language"
        component={LeafletCoverSheet}
      />
      <Route
        exact
        path="/missed-opportunities-report"
        component={MissedOppurtunitiesReport}
      />
      <Route
        exact
        path="/tp-receivables-by-reg-acct-159"
        component={TPReceivables}
      />
      <Route
        exact
        path="/wait-for-drug"
        component={WaitForDrugOrder}
      />
      <Route exact path="/partial-fill" component={PartialFill} />
      <Route exact path="/compliance" component={Compliance} />
      <Route
        exact
        path="/hundred-days-drugs-not-used"
        component={HundredDaysDrugsNotUsed}
      />
      <Route exact path="/cancel-fill" component={CancelFill} />
      <Route exact path="/bagging-detail" component={BaggingMain} />
      <Route
        exact
        path="/cii-digital-logbook"
        component={CIIDigitalLogbook}
      />
      <Route
        exact
        path="/will-call-bin"
        component={WillCallBinMain}
      />
      <Route exact path="/cycle-count" component={CycleCount} />
      <Route
        exact
        path="/replenishment-unavailable"
        component={ReplenishmentUnAvailable}
      />
      <Route
        exact
        path="/replenishment-available"
        component={ReplenishmentAvailable}
      />
      <Route
        exact
        path="/regulatory-patient-profile"
        component={RegulatoryPatientProfileReport}
      />
      <Route
        exact
        path="/order-completion-performance"
        component={OrderCompletionPerformance}
      />
    </Router>
  );
}

export default App;
