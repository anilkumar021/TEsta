export const API_URL = process.env.REACT_APP_NODE_ENV.trim();

const endPoints = {
  'rx-report': '/rx-report',
  '4-point-check-report': '/4-point-check-report',
  'tp-receivables-by-reg-acct-159': '/tp-receivables-by-reg-acct-159',
  'pharmacy-activity': '/pharmacy-activity',
  'central-fill-performance-report':
  '/central-fill-performance-report',
  'controlled-substance-pickup-report':
  '/controlled-substance-pickup-report',
  'leaflet-cover-sheet-printed-by-language':
  '/leaflet-cover-sheet-printed-by-language',
  'missed-opportunities-report': '/missed-opportunities-report',
  'pharmacy-business-summary': '/pharmacy-business-summary',
  'remote-order-review': '/remote-order-review',
  'wait-for-drug-order': '/wait-for-drug',
  'cancel-fill': '/cancel-fill',
  'partial-fill': '/partial-fill',
  'on-hold': '/on-hold',
  'compliance': '/compliance',
  'replenishment-unavailable': '/replenishment-unavailable',
  'replenishment-available': '/replenishment-available',
  'cycle-count': '/cycle-count-report',
  'regulatory-patient-profile': '/regulatory-patient-profile',
  'cii-digital-logbook': '/cii-digital-logbook',
  'bagging-detail': '/bagging-detail',
  'auto-fill-utilization': '/auto-fill-utilization',
  'will-call-bin': '/will-call-bin',
  'drug-inventory-onhand': '/drug-inventory-onhand'
};

//jest.setTimeout(1000 * 60 * 10);

export const getConfig = (id) => endPoints[id];
