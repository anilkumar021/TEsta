import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from './Table';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import { getApi } from '../Common/AxiosCalls';

/**
 * Pharmacist Business Summary
 */
export class PharmacistBusinessSummary extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const startDate = params.get('startDate');
    const endDate = params.get('endDate');
    const reportType = params.get('reportType');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    // axios.get(URL, { params: { startDate, endDate, reportType } })
    //   .then(({ data }) => this.setState({ data, loading: false, error: null }))
    //   .catch(({ message }) => this.setState({ data: null, error: message, loading: false }));
    getApi(
      URL,
      { startDate, endDate, reportType },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    const summary = Object.values(data.summary);
    return (
      <div className="report-container" id="reportContainer">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">
              {`Report Date : 
              ${String(
                new Date(data.date).toLocaleDateString('en-US'),
              )}`}
            </p>
          </Grid>
          <Grid item xs={4}>
            <center>
              <h5 className="pharma-header">{data.appName}</h5>
              <h5 className="pharma-header">{data.store}</h5>
              <h5 className="pharma-header">{data.reportName}</h5>
              <h5 className="pharma-header">{data.details}</h5>
              <h5 className="pharma-header">
                {`Date : 
                ${String(new Date().toLocaleDateString('en-US'))}`}
              </h5>
            </center>
          </Grid>
        </Grid>
        <p className="divider-line" />
        {summary.map((report) => (
          <React.Fragment key={report.label}>
            <Grid>
              <div
                className="report-params"
                style={{ marginTop: '25px', borderTop: 'none' }}
              >
                <center>
                  <h5 className="pharma-header">{report.label}</h5>
                </center>
              </div>
              <Grid container style={{ marginBottom: '30px' }}>
                <Table
                  data={report.data}
                  header={report.header}
                  id={report.id}
                />
              </Grid>
            </Grid>
            {report.id === 'salesPerformance' && (
              <Grid>
                <p className="divider-line" />
                <Grid container spacing={10}>
                  <Grid item xs={3}>
                    <h5 className="pharma-header">
                      {report.pos.label}
                    </h5>
                    <h5 className="pharma-header">
                      {report.pos.description}
                    </h5>
                  </Grid>
                  <Grid item xs={4}>
                    <h5 className="pharma-header">
                      {report.pos.value
                        ? report.pos.value
                        : 'CURRENTLY UNAVAILABLE'}
                    </h5>
                  </Grid>
                </Grid>
              </Grid>
            )}
          </React.Fragment>
        ))}
      </div>
    );
  }
}

PharmacistBusinessSummary.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(PharmacistBusinessSummary);
