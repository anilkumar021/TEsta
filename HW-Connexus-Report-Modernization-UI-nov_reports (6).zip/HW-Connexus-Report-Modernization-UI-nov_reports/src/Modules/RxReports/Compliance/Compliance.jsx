import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../Common/PrintReport';
import Table from './Table';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';

/**
 * Compliance Component
 */
export class Compliance extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false - finished loading
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname= '' } = location;
    const params = new URLSearchParams(search);
    const queryParams = {};
    [...params.keys()].forEach((key) => {
      queryParams[key] = params.get(key);
    });
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      queryParams,
      {},
      (res) => {
        this.setState({ data: res.data, loading: false, error: null });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">
              {`Report Date :${data.date}`}
            </p>
            <br />
            <p className="para">{data.complianceSummaryHeaderBO.complianceIndex === 'Y' ? data.complianceSummaryHeaderBO.dateRange : 'Next Fill Date: ' + data.complianceSummaryHeaderBO.dueDate}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
            <h5 className="pharma-header">
              {`By Next Fill Date ${data.complianceSummaryHeaderBO.showPatientIndex === 'Y' ? ', Patient' : ''} 
              ${data.complianceSummaryHeaderBO.showPrescriberIndex === 'Y' ? ', Physician' : ''} ${data.complianceSummaryHeaderBO.includeDeceasedPatientsData === 'true' ? ', DRUG' : ''}`}
            </h5>
          </Grid>
        </Grid>
        {/* Add the one column for Drug name, if user search by drug. */}
        {data.complianceSummaryHeaderBO.includeDeceasedPatientsData === 'true' && (
          <div>
            <p className="divider-line" />
            <h5 className="pharma-header">
              {`Drug: ${data.complianceSummaryHeaderBO.drugName}`}
            </h5>
          </div>
        )}
        <p className="divider-line" />
        <h5 className="pharma-header">
          {`Due Date: ${data.complianceSummaryHeaderBO.dueDate}`}
        </h5>
        <br />

        <Table data={data.data} header={data.complianceSummaryHeaderBO.header} drug={data.complianceSummaryHeaderBO.includeDeceasedPatientsData} />
      </div>
    );
  }
}
/**
 * propTypes
 * @property {object} location windows location object
 */

Compliance.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};
export default PrintWrapper(Compliance);
