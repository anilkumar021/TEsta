import React, { Component, Fragment } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../../assets/table.css';

export default class CustomTable extends Component {
  /**
   * Change the header for table depend on user search by drug or not.
   * @param {String} label the Label for header
   * @param {String} drug true for user search by drug and false for not.
   */
  header(label, drug) {
    if (drug === "true" && label === "DrugName") {
      label = "Patient";
    }
    if (drug !== "true" && label === "Qty") {
      label = "";
    }
    return label
  }
  /**
   * Change table data format depend on user search by drug or not.
   * @param {List} data Table data
   * @param {String} row 
   * @param {String} drug 
   */
  body(data, row, drug) {
    if (row === "drugName" && drug !== "true") {
      return (
        <div>{data["drugName"]}<br />Qty: {data["quantity"]}</div>
      )
    }
    if (row === "quantity" && drug !== "true") {
      return ""
    }
    return data[row]

  }
  render() {
    const { data: patientData, header: rows, drug: checkDrug } = this.props;
    return (
      <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
        <TableHead style={{ width: '100%' }}>
          <TableRow className="table-header-row">
            {rows.map((row) => (
              <TableCell
                className="table-header-cell"
                key={row.id}
              >
                {this.header(row.label, checkDrug)}
              </TableCell>
            )
            )}
          </TableRow>
        </TableHead>
        <TableBody id="reportTableBody" className="report-table-body">
          {patientData.length > 0 ? (
            patientData.map((n, index) => (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={index}
              >
                {rows.map(
                  (row) => (
                    <TableCell key={index} style={{ padding: '4px 6px 4px 6px', fontSize: '11px', borderBottom: '0px' }}>

                      {this.body(n, row.id, checkDrug)}
                    </TableCell>
                  ),
                  this,
                )}
              </TableRow>

            ))
          ) : (
              <TableRow
                hover
                tabIndex={-1}
              >
                <Fragment>
                  <TableCell colSpan={12}>
                    <div className="alert alert-warning" role="alert">
                      No Record Found
									</div>
                  </TableCell>
                </Fragment>
              </TableRow>
            )}
        </TableBody>
      </Table>
    )
  }
}