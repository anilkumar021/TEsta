import React, { Component } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../../assets/table.css';

export default class CustomTable extends Component {
  render() {
    const { data: cancelFillData, header: rows } = this.props;
    return (
      <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
        <TableHead style={{ width: '100%' }}>
          <TableRow className="table-header-row">
            {rows.map(
              row => (
                <TableCell
                  className="table-header-cell"
                  key={row.id}
                >
                  {row.label}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
        </TableHead>
        <TableBody id="reportTableBody">
          {
            cancelFillData.map((n, index) => {
              return (
                <TableRow
                  id={`reportTableRow` + index}
                  hover
                  tabIndex={-1}
                  key={index}
                >
                  {rows.map(
                    (row, i) => (
                      <TableCell style={{ padding: '4px 6px 4px 11px', fontSize: "11px", borderBottom: "0px" }}
                        key={i}>
                        {row.id === 'fillDate' || row.id === 'cancelDate' ?
                          String((new Date(n[row.id])).toLocaleDateString('en-US')) : n[row.id]}
                      </TableCell>
                    ),
                    this,
                  )}
                </TableRow>


              );
            })
          }

        </TableBody>
      </Table>
    )
  }
}