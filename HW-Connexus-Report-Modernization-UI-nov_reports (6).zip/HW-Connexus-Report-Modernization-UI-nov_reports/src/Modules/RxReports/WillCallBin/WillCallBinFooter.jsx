import React from 'react';
import PropTypes from 'prop-types';
import { TableFooter, TableRow, TableCell } from '@material-ui/core';

const footerComponent = (props) => {
  const {
    totalUnsoldPres,
    totalUnsoldOrders,
    totalUnsoldPresCost,
    totalUnsoldPresPrice,
    totalNewPres,
    totalRefillPres,
    totalPresUsingMess,
  } = props;

  return (
    <TableFooter>
      <TableRow>
        <TableCell
          style={{
            margin: '0',
            color: 'black',
            textAlign: 'left',
            padding: '10px 0 0 0',
          }}
        >
          <p className="will-call-footer">
            Total Unsold Prescriptions :
            <span className="red">{totalUnsoldPres}</span>
          </p>
          <p className="will-call-footer">
            Total Unsold Orders :
            <span className="red">{totalUnsoldOrders}</span>
          </p>
          <p className="will-call-footer">
            Total Unsold Prescriptions cost :
            <span className="blue">{`$${totalUnsoldPresCost}`}</span>
          </p>
          <p className="will-call-footer">
            Total Unsold Prescriptions price :
            <span className="blue">{`$${totalUnsoldPresPrice}`}</span>
          </p>
          <p className="will-call-footer">
            Total New Prescriptions :
            <span className="blue">{totalNewPres}</span>
          </p>
          <p className="will-call-footer">
            Total Refill Prescriptions :
            <span className="blue">{totalRefillPres}</span>
          </p>
          <p className="will-call-footer">
            Total Prescriptions using Prescription Messaging :
            <span className="blue">{totalPresUsingMess}</span>
          </p>
        </TableCell>
      </TableRow>
    </TableFooter>
  );
};

footerComponent.defaultProps = {
  totalUnsoldPres: 0,
  totalUnsoldOrders: 0,
  totalUnsoldPresCost: 0,
  totalUnsoldPresPrice: 0,
  totalNewPres: 0,
  totalRefillPres: 0,
  totalPresUsingMess: 0,
};

footerComponent.propTypes = {
  totalUnsoldPres: PropTypes.number,
  totalUnsoldOrders: PropTypes.number,
  totalUnsoldPresCost: PropTypes.number,
  totalUnsoldPresPrice: PropTypes.number,
  totalNewPres: PropTypes.number,
  totalRefillPres: PropTypes.number,
  totalPresUsingMess: PropTypes.number,
};

export default footerComponent;
