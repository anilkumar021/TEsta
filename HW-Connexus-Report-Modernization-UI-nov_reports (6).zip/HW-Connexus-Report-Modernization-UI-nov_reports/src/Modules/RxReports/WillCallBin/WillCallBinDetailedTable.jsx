import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React from 'react';
import '../../../assets/table.css';

const WillCallBinDetailedTable = ({
  data: patientData,
  header: rows,
  footer,
}) => {
  /**
   * @desc checks patient name for notation, returns classname for matching style
   * @param {object} data - patient object
   * @return {string} classname string
   */
  const notationClassName = (n) => {
    const asteriskArr = n.patient.match(/(\*)/g)
      ? n.patient.match(/(\*)/g)
      : [];

    switch (asteriskArr.length) {
      case 1:
        return 'will-call-warning';
      case 2:
        return 'will-call-lockout';
      default:
        return '';
    }
  };

  return (
    <Table
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table"
    >
      <TableHead style={{ width: '100%' }}>
        <TableRow className="table-header-row">
          {rows.map(
            (row) => (
              <TableCell className="table-header-cell" key={row.id}>
                {row.label}
              </TableCell>
            ),
            this,
          )}
        </TableRow>
      </TableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {patientData.length > 0 ? (
          patientData.map((n, index) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={`${n.unique}`}
              className={notationClassName(n)}
            >
              {rows.map(
                (row) => (
                  <TableCell
                    key={`${row.id} - ${n.unique}`}
                    style={{
                      padding: '4px 6px 4px 6px',
                      fontSize: '11px',
                      border: '1px solid white',
                    }}
                  >
                    {n[row.id]}
                  </TableCell>
                ),
                this,
              )}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div className="alert alert-warning" role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </TableBody>
      {footer}
    </Table>
  );
};

WillCallBinDetailedTable.defaultProps = {
  data: [],
  header: [],
  footer: null,
};

WillCallBinDetailedTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
  footer: PropTypes.element,
};

export default WillCallBinDetailedTable;
