import moment from 'moment';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';
import WillCallBinDetailed from './WillCallBinDetailed';
import WillCallBinSummary from './WillCallBinSummary';

/**
 * WillCallBinMain Smart Component
 * (RE-VISIT) May need to conditionally render the Dispense Method column - need real data to confirm
 */
class WillCallBinMain extends Component {
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     * @property {boolean} isSummaryReport Conditional Rendering Predicate
     * @property {object} footerData Calculated totals for bottom of Detail/Summary Reports
     * @property {array} summaryTableData Calculated table data for Summary Report
     * @property {object} notes Object used for conditionally rendering notes at bottom of Detail Report
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
      isSummaryReport: false,
      footerData: {},
      summaryTableData: [],
      notes: {},
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams = {};
    [...params.keys()].forEach((key) => {
      queryParams[key] = params.get(key);
    });
    let { isSummaryReport } = queryParams;
    isSummaryReport = isSummaryReport === 'True' || false;
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);

    getApi(
      URL,
      queryParams,
      header,
      ({ data }) => {
        this.setState((prevState) => ({
          ...prevState,
          ...this.getParsedResponseData(data, isSummaryReport),
          loading: false,
        }));
      },
      (error) => {
        this.setState({ data: null, error, loading: false });
      },
    );
  }

  getParsedResponseData = (data, isSummaryReport) => {
    const footerData = this.getFooterData(data);

    const summaryTableData = isSummaryReport
      ? this.getSummaryTableData(data)
      : null;

    const reportName = isSummaryReport
      ? 'WILL CALL BIN SUMMARY REPORT'
      : data.reportName;

    const { notes, annotatedTableData } = !isSummaryReport
      ? this.getAnnotatedTableData(data)
      : { notes: null, annotatedTableData: data.data };

    const parsedResponseData = {
      ...data,
      reportName,
      data: annotatedTableData,
    };

    return {
      data: parsedResponseData,
      isSummaryReport,
      footerData,
      summaryTableData,
      notes,
    };
  };

  getAnnotatedTableData = ({ data: prescriptions }) => {
    const notes = {
      isWarning: false,
      isLockout: false,
      wasNotified: false,
      isEnrolled: false,
      incompleteScripts: false,
    };

    const MIN_PICKUP_DAYS = 20;
    const MAX_PICKUP_DAYS = 29;
    const currentDate = moment('20201207', 'YYYYMMDD');
    let daysDiff = 0;

    const annotatedTableData = prescriptions.map((script) => {
      let notify = '';
      let asteriskString = '';
      let orderIdentifier = '';
      let readyReminderEnrolledString = '';
      const activityTs = moment(script.activityTs, 'MM-DD-YYYY');

      if (script.activityTs) {
        daysDiff = moment(currentDate).diff(activityTs, 'days');
      }

      if (daysDiff > MIN_PICKUP_DAYS && daysDiff <= MAX_PICKUP_DAYS) {
        asteriskString = '*';
        notes.isWarning = true;
      }

      if (daysDiff > MAX_PICKUP_DAYS) {
        asteriskString = '**';
        notes.isLockout = true;
      }

      if (script.patNotifyInd === 1) {
        notify = '^';
        notes.wasNotified = true;
      }

      if (script.patientEnrolled) {
        readyReminderEnrolledString = '&';
        notes.isEnrolled = true;
      }

      if (script.rxCount > 0) {
        orderIdentifier = '#';
        notes.incompleteScripts = true;
      }

      const noteStringBuilder =
        readyReminderEnrolledString +
        asteriskString +
        notify +
        orderIdentifier;

      return {
        ...script,
        patient: `${noteStringBuilder}${script.patient}`,
      };
    });
    return { annotatedTableData, notes };
  };

  getSummaryTableData = ({ data: prescriptions }) => {
    const summaryTableMap = {};

    prescriptions.forEach(({ day }, id) => {
      if (!summaryTableMap[day])
        summaryTableMap[day] = { id, dayNo: day, rxCount: 0 };
      summaryTableMap[day].rxCount += 1;
    });

    return Object.values(summaryTableMap);
  };

  getFooterData = ({ data: prescriptions }) => {
    const footerData = {
      totalUnsoldPres: prescriptions.length,
      totalUnsoldOrders: 0,
      totalUnsoldPresCost: 0,
      totalUnsoldPresPrice: 0,
      totalNewPres: 0,
      totalRefillPres: 0,
      totalPresUsingMess: 0,
    };

    const orderTracker = new Set();
    prescriptions.forEach((script) => {
      if (script.patNotifyInd === 1)
        footerData.totalPresUsingMess += 1;

      if (script.newOrRefill === 'N') footerData.totalNewPres += 1;
      if (script.newOrRefill === 'R') footerData.totalRefillPres += 1;

      footerData.totalUnsoldPresPrice = Number.parseFloat(
        (footerData.totalUnsoldPresPrice + script.price).toFixed(2),
      );
      footerData.totalUnsoldPresCost = Number.parseFloat(
        (footerData.totalUnsoldPresCost + script.cost).toFixed(2),
      );

      if (!orderTracker.has(script.orderId)) {
        orderTracker.add(script.orderId);
        footerData.totalUnsoldOrders += 1;
      }
    });

    return footerData;
  };

  render() {
    const { loading, error, isSummaryReport } = this.state;

    if (loading) return <div>Loading ....</div>;

    if (error) return <div>{`Error: ${error}`}</div>;

    return isSummaryReport ? (
      <WillCallBinSummary {...this.props} state={{ ...this.state }} />
    ) : (
      <WillCallBinDetailed
        {...this.props}
        state={{ ...this.state }}
      />
    );
  }
}

WillCallBinMain.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default WillCallBinMain;
