import { Grid } from '@material-ui/core';
import PropTypes from 'prop-types';
import React from 'react';
import PrintWrapper from '../../Common/PrintReport';
import Table from './WillCallBinDetailedTable';
import footerComponent from './WillCallBinFooter';

/**
 * WillCallBinDetailed Component
 */
export const WillCallBinDetailed = ({ state }) => {
  const { data, loading, error, footerData, notes } = state;

  const {
    isWarning,
    isLockout,
    wasNotified,
    isEnrolled,
    incompleteScripts,
  } = notes;

  if (loading) {
    return <div>Loading ....</div>;
  }
  if (error) {
    return <div>{`Error: ${error}`}</div>;
  }
  return (
    <div className="report-container">
      <Grid container spacing={10}>
        <Grid item xs={4}>
          <p className="para">{`Store #: ${data.storeId}`}</p>
          <p className="para">{`Report Date: ${data.reportDate}`}</p>
        </Grid>
        <Grid item xs={4}>
          <h5 className="pharma-header">{data.appName}</h5>
          <h5 className="pharma-header">{data.store}</h5>
          <h5 className="pharma-header">{data.reportName}</h5>
        </Grid>
      </Grid>
      <Table
        data={data.data}
        header={data.header}
        footer={footerComponent(footerData)}
      />
      <div style={{ textAlign: 'left' }}>
        {isWarning && (
          <p className="notes warnings">
            NOTE: * denotes Pickup WARNINGS
          </p>
        )}
        {isLockout && (
          <p className="notes lockouts">
            NOTE: ** denotes Pickup LOCKOUTS
          </p>
        )}
        {wasNotified && (
          <p className="notes">
            NOTE: ^ denotes Patient received order ready text/voice
            message.
          </p>
        )}
        {incompleteScripts && (
          <p className="notes">
            NOTE: # denotes Patient not notified due to all
            prescriptions in order not being complete.
          </p>
        )}
        {isEnrolled && (
          <p className="notes">
            NOTE: & denotes Patient enrolled for messaging.
          </p>
        )}
      </div>
    </div>
  );
};

/**
 * propTypes
 * @property {object} location windows location object
 */
WillCallBinDetailed.propTypes = {
  state: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(WillCallBinDetailed);
