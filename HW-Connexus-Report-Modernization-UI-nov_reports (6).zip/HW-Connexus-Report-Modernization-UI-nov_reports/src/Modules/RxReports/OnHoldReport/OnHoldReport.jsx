import { Grid } from '@material-ui/core';
import React, { Component } from 'react';
import { getApi } from '../../Common/AxiosCalls';
import PrintWrapper from '../../Common/PrintReport';
import Table from '../../Common/Table';
import { API_URL, getConfig } from '../../../settings';

/**
 * Compliance Component
 */

export class OnHoldReport extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */

  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(URL, {
      fromDate,
      toDate
    }, header, (res) => {
      this.setState({ data: res.data, loading: false, error: null });
    }, (err) => {
      this.setState({ data: null, error: err, loading: false });
    });
    // getApi(
    //   'on-hold-report.json',
    //   {},
    //   {},
    //   (res) => this.setState({ data: res.data, loading: false, error: null }),
    //   (err) => this.setState({ data: null, error: err, loading: false }),
    // );
  }

  /**
   * render
   * @return {ReactElement} markup
   */

  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error: ${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store #: ${data.storeNumber}`}</p>
            <p className="para">{`Report Date: ${data.reportDate}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
        </Grid>
        <p className="para">{`From: ${data.from} To ${data.to}`}</p>
        <Table data={data.data} header={data.header} />
        <h5>{data.note}</h5>
      </div>
    );
  }
}
// npx eslint src/
/**
 * propTypes
 * @property {object} location windows location object
 */
export default PrintWrapper(OnHoldReport);
