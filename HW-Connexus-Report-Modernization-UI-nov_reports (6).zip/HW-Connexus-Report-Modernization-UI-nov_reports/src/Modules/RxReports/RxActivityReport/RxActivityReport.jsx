import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import {getApi} from "../../Common/AxiosCalls";

/**
 * RxActivityReport Component
 */
export class RxActivityReport extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
       * @type {object}
       * @property {object} data Input Data
       * @property {boolean} loading Loading Flag
       * @property {string} error Error Message
       */
    this.state = {
      data: null,
      loading: true,
      error: null,
      startTest: new Date(), // grabs current Date and Time at initialization when component is hit via URL
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { startTest } = this.state;

    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const rxNumber = params.get('rxNumber');
    const fillDate = params.get('fillDate');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(URL, {rxNumber, fillDate}, header, (res) => {
      this.setState({ data:res.data, loading: false, error: null }, () => {
         // Call Back function that will run upon completion of setState method which sets the response data to state
        // Call back below gets a Current Date and Time and logs it along with time taken (will refactor this at a later time)
        const endTime = new Date();
        console.log(`URL HIT (Component): ${startTest.toLocaleTimeString('en-US', { hour12: false })}:${ startTest.getMilliseconds()}`);
        console.log(`Component Rendered w/ Response Data: ${endTime.toLocaleTimeString('en-US', { hour12: false })}:${ endTime.getMilliseconds()}\ntime taken: ${endTime.getTime() - startTest.getTime()}ms`);
      })
     },(err) => {
          this.setState({ data: null, error: err, loading: false })
      });
    // axios.get(URL, { params: { rxNumber, fillDate } })
    //   .then(({ data }) => this.setState({ data, loading: false, error: null }))
    //   .catch(({ message }) => this.setState({ data: null, error: message, loading: false }));
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data, loading, error } = this.state;
    const { location = {} } = this.props;
    const { search } = location;
    const params = new URLSearchParams(search);
    const storeId = params.get('storeId');
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return (
        <div>
          Error :{error}
        </div>
      );
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">
              Store # :{storeId}
            </p>
            <p className="para">
              Report Date :{moment().format('MM/DD/YYYY')}
            </p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <Table data={data.data} header={data.header} />
        <h5>
          {data.note}
          {' '}
        </h5>
      </div>
    );
  }
}

/**
 * propTypes
 * @property {object} location windows location object
 */
RxActivityReport.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(RxActivityReport);
