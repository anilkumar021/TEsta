import React from 'react'

export class CurrentOnHoldInventorySummaryFooter extends React.Component {
  render() {
    return (
      <div>
        <div
          className="bottom-border"
          id="currentOnHoldInventorySummaryFooter"
          style={{ borderTop: ' 1px solid #000' }}>
          <div className="data_row">
            <p> Recommended on-hand inventory value by script volume.</p>
          </div>
          <div className="data_row">
            <p> {` < 1,000 Rx/Week: $200K`}</p>
          </div>
          <div className="data_row">
            <p> 1,000 to 1,500 Rx/Week: $300K</p>
          </div>
          <div className="data_row">
            <p> 1,500 to 2,000 Rx/Week: $400K</p>
          </div>
          <div className="data_row">
            <p> 2,000 to 3,000 Rx/Week: $500K</p>
          </div>
          <div className="data_row">
            <p> 3,000 to 4,000 Rx/Week: $550K</p>
          </div>
          <div className="data_row">
            <p> {`> 4,000 Rx/Week: $600K`}</p>
          </div>
        </div>
      </div>
    )
  }
}
