import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React, { Fragment } from 'react';
import '../../../assets/table.css';

const OnHoldInventoryTable = ({ data: drugInfo, header: rows }) => {
  // Function receives object and renders a data set with header and relational data
  // Data received by this function is expected to have a one to many relationship
  const renderDataSet = (data) => {
    let totalSupply = 0;
    let totalQuantity = 0;
    let totalCost = 0;

    if (data.info.length) {
      data.info.forEach((info) => {
        rows.forEach((row) => {
          if (row.id === 'supply') totalSupply += info[row.id];
          if (row.id === 'quantity') totalQuantity += info[row.id];
          if (row.id === 'costAmount') totalCost += info[row.id];
        });
      });
      return (
        <Fragment key={Object.values(data)[0]}>
          <TableRow className="table-header-row" hover tabIndex={-1}>
            {rows.map((row) => {
              let rowHeader = '';
              switch (row.id) {
                case 'drugNDC':
                  rowHeader = data.drugNDC;
                  break;
                case 'supply':
                  rowHeader = totalSupply === 0 ? 'No Demand' : totalSupply;
                  break;
                case 'quantity':
                  rowHeader = totalQuantity;
                  break;
                case 'costAmount':
                  rowHeader = `$ ${totalCost}`;
                  break;
                default:
                  rowHeader = null;
              }
              if (row.id === 'rxNbr') return null;

              return (
                <TableCell
                  style={{
                    padding: '4px 6px 4px 6px',
                    fontSize: '11px',
                  }}
                >
                  <strong>{rowHeader}</strong>
                </TableCell>
              );
            })}
          </TableRow>

          {data.info.map((info, index) => {
            const styleObj = {
              padding: '4px 6px 4px 6px',
              fontSize: '11px',
              bottomBorder: '0px',
            };
            return (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={`${info.unique}-table-row-data-set`}
              >
                {rows.map((row, idx) => {
                  if (idx === 0) return null;

                  if (index === data.info.length - 1) {
                    styleObj.borderBottom = '1px solid black';
                  }
                  return (
                    <TableCell
                      key={info.unique + info[row.id]}
                      style={styleObj}
                    >
                      {info[row.id]}
                    </TableCell>
                  );
                })}

                <TableCell style={styleObj} />
              </TableRow>
            );
          })}
        </Fragment>
      );
    }
    return null;
  };

  return (
    <Table
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table"
    >
      <TableHead style={{ width: '100%' }}>
        <TableRow className="table-header-row">
          {rows.map((row, i) => {
            if (i === 1) return null;
            return (
              <TableCell
                key={`${row.id}-${row.unique}-table-header-cell`}
                className="table-header-cell"
              >
                {row.label}
              </TableCell>
            );
          })}
          <TableCell
            style={{
              padding: '4px 6px 4px 6px',
              fontSize: '11px',
              borderBottom: '1px solid black',
            }}
          />
        </TableRow>
      </TableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {drugInfo.length > 0 ? (
          drugInfo.map((n) => renderDataSet(n))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div className="alert alert-warning" role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

OnHoldInventoryTable.defaultProps = {
  data: [],
  header: [],
};

OnHoldInventoryTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
};

export default OnHoldInventoryTable;
