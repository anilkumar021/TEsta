import { Grid } from '@material-ui/core';
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';
import { CurrentOnHoldInventorySummaryTable } from './CurrentOnHoldInventorySummaryTable';
import { CurrentOnHoldInventorySummaryFooter } from './CurrentOnHoldInventorySummaryFooter'; import './CurrentOnHoldInventorySummaryStyle.css';

/**
 *  Current On Hold Inventory Sumary Report
 */
export class CurrentOnHoldInventorySummary extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false which mean done with load
     * @property {string} error Handle error Message
     * @property {string} date Handle date
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
      date: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const queryParams = {};
    [...params.keys()].forEach((key) => {
      queryParams[key] = params.get(key);
    });
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);

    getApi(
      URL,
      queryParams,
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }
  /**
   * render
   * @return {ReactElement}  content for this component
   */

  render() {
    const { data, loading, error } = this.state;

    if (loading) {
      return (
        <div>Loading ....</div>
      )
    }
    if (error) {
      return (
        <div>Error :{' '}{error}</div>
      );
    }

    return (
      <div className="report-container">
        <Grid container spacing={10} style={{ borderBottom: "1px" }}>
          <Grid item xs={4}>
            <p className="para">{`Store #: ${data.storeId}`}</p>
            <p className="para">{`Report Date: ${data.reportDate}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
        </Grid>
        <div>
          {
            data.headers.map((report, index) => {
              let reportId = report.id;
              return (
                (index === 0) ?
                  (<CurrentOnHoldInventorySummaryTable
                    title={report.label}
                    data={data.data[reportId]}
                    header={report.header}
                    key={index}
                    centerTitle={true}

                  />)
                  :
                  (
                    <CurrentOnHoldInventorySummaryTable
                      title={report.label}
                      data={data.data[reportId]}
                      header={report.header}
                      key={index}
                      centerTitle={false}
                    />)

              )
            })
          }
        </div>
        <CurrentOnHoldInventorySummaryFooter />

      </div>
    );
  }
}

CurrentOnHoldInventorySummary.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(CurrentOnHoldInventorySummary);
