import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from './Table';
import PrintWrapper from '../../Common/PrintReport';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';

/**
 * WaitForDrugOrder Component
 */
export class WaitForDrugOrder extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const sortOption = params.get('sortOption');
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    const header = {};

    getApi(
      URL,
      {
        fromDate,
        toDate,
        sortOption,
      },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error: ${error}`}</div>;
    }

    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store #: ${data.storeId}`}</p>
            <p className="para">{`Report Date: ${data.date}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <br />
        <p className="para">{`From: ${data.dateRange.from} To: ${data.dateRange.to}`}</p>
        <Table data={data.data} header={data.header} />
      </div>
    );
  }
}

/**
 * propTypes
 * @property {object} location windows location object
 */
WaitForDrugOrder.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(WaitForDrugOrder);
