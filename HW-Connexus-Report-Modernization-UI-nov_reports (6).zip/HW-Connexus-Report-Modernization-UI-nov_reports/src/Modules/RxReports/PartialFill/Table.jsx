import React from 'react';
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from '@material-ui/core';

function customTable({ header, data, noOfRows = 1 }) {
  let key = "";
  return (
    <Table
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table pf-table"
    >
      <TableHead style={{ width: "100%" }}>
        {frameCells(header, noOfRows, "table-header-row")}
      </TableHead>
      <TableBody id="reportTableBody">
        {data.length > 0 ? (
          data.map((item, idx) => (
            <TableRow key={item.rxNo + idx}>
              {header.map((heading, idx) => {
                key =
                  noOfRows === 1
                    ? item[heading["id"]] + idx
                    : item[heading["id" + 1]] + idx;
                return (
                  <TableCell
                    className="table-header-cell"
                    style={{
                      padding: "4px 6px 4px 6px",
                      fontSize: "11px",
                      borderBottom: "0px"
                    }}
                    key={key}
                  >
                    {noOfRows === 1 ? (
                      item[heading["id"]]
                    ) : <>
                        {item[heading["id" + 1]]}
                        <br />
                        {item[heading["id" + 2]]}
                        </>
                    }
                  </TableCell>
                );
              })}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div
                  className="alert alert-warning"
                  role="alert"
                  style={{
                    textAlign: 'center',
                    fontWeight: 600,
                    color: 'deeppink',
                  }}
                >
                  No Records Found
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}
const frameCells = (data, noOfRows, rowClass) => {
  let rows = [],
    key = "";
  const subRows = [];
  data.forEach((item, idx) => {
    key = noOfRows !== 1 ? item.label1 + idx : item.label + idx;
    subRows.push(
      <TableCell
        className="table-header-cell"
        style={{
          padding: "4px 6px 4px 6px",
          fontSize: "11px",
          borderBottom: "0px"
        }}
        key={key}
      >
        {noOfRows === 1 ? (
          item.label
        ) : 
          <>
            {item.label1}
            <br/>
            {item.label2}
            </>
        }
      </TableCell>
    );
  });
  rows.push(
    <TableRow className={rowClass} key={key + "h"}>
      {subRows}
    </TableRow>
  );
  return rows;
};
export default customTable;
