import { Grid } from '@material-ui/core';
// import PropTypes from 'prop-types';
import React, { Component } from 'react';
import PrintWrapper from '../../Common/PrintReport';
import Table from './SummaryTable';
import { getApi } from '../../Common/AxiosCalls';
import { API_URL, getConfig } from '../../../settings';

/**
 * AutoFillSummary Component
 */
export class AutoFillSummary extends Component {
  /**
   * @desc calculates totals, returns object w/ k,v pairs representing header ids & column totals
   * @param {object} data - response object
   * @return {object} aggregate object
   */
  static calculateTotals({ data }) {
    const excluded = new Set(['date', 'unique', 'orders']);
    return data.reduce((aggObj, obj) => {
      const keys = Object.keys(obj);
      keys.forEach((key) => {
        if (!excluded.has(key)) {
          if (!aggObj[key]) aggObj[key] = 0;
          // Need to add logic for utilization % calculation
          aggObj[key] += obj[key];
        }
      });
      return aggObj;
    }, {});
  }

  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {object} totals Aggregate Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      totals: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    // getApi(
    //   'autofillsummary.json',
    //   {},
    //   {},
    //   (res) => {
    //     const totals = AutoFillSummary.calculateTotals(res.data);
    //     this.setState({
    //       data: res.data,
    //       totals,
    //       loading: false,
    //       error: null,
    //     });
    //   },
    //   (err) => {
    //     this.setState({ data: null, error: err, loading: false });
    //   },
    // );

    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const sortBy = params.get('sortBy');
    const reportType = params.get('reportType');
    const patientId = params.get('patientId');
    const rxNumber = params.get('rxNumber');
    const Connector = params.get('Connector');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      {
        fromDate,
        toDate,
        sortBy,
        reportType,
        patientId,
        rxNumber,
        Connector
      },
      header,
      (res) => {
        const totals = AutoFillSummary.calculateTotals(res.data);
        this.setState({
          data: res.data,
          totals,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const {
      data,
      totals,
      loading,
      error,
    } = this.state;

    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error: ${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={10}>
          <Grid item xs={4}>
            <p className="para">{`Store #: ${data.storeId}`}</p>
            <p className="para">{`Report Date: ${data.reportDate}`}</p>
            <br />
            <p className="para">{`From: ${data.dateRange}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <Table data={data.data} header={data.header} totals={totals} />
        <h5 style={{ textAlign: 'center' }}>
          {data.note}
          {
            '***PRIVATE-IF YOU SEE THIS REPORT IN ERROR, PLEASE RETURN TO WAL-MART PHARMACY IMMEDIATELY***'
          }
        </h5>
      </div>
    );
  }
}

/**
 * propTypes
 * @property {object} location windows location object
 */
// AutoFillSummary.propTypes = {
//   location: PropTypes.objectOf(PropTypes.any).isRequired,
// };

export default PrintWrapper(AutoFillSummary);
