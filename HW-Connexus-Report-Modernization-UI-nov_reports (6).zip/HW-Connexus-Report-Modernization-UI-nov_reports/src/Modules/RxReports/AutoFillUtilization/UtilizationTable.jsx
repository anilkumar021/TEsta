import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React, { Fragment } from 'react';
import '../../../assets/table.css';

const UtilizationTable = ({ data: patientData, header: rows }) => {
  // Function receives object and renders a data set with header and relational data
  // Data received by this function is expected to have a one to many relationship
  const renderDataSet = (data) => {
    // check if orders exist before returning jsx
    if (data.orders.length) {
      return (
        <Fragment key={Object.values(data)[0]}>
          <TableRow className="table-header-row" hover tabIndex={-1}>
            <TableCell
              style={{
                padding: '4px 6px 4px 6px',
                fontSize: '11px',
                borderBottom: '0px',
              }}
            >
              {Object.values(data)[0]}
            </TableCell>
          </TableRow>

          {data.orders.map((order, index) => (
            <TableRow
              id={`reportTableRow${index}`}
              hover
              tabIndex={-1}
              key={`${order.unique}-table-row-data-set`}
            >
              {rows.map((row, idx) => {
                if (idx === 0) return null;
                return (
                  <TableCell
                    key={order.unique + order[row.id]}
                    style={{
                      padding: '4px 6px 4px 6px',
                      fontSize: '11px',
                      borderTop: '1px solid black',
                    }}
                  >
                    {order[row.id]}
                  </TableCell>
                );
              })}
              <TableCell
                style={{
                  padding: '4px 6px 4px 6px',
                  fontSize: '11px',
                  borderTop: '1px solid black',
                }}
              />
            </TableRow>
          ))}
        </Fragment>
      );
    }
    return null;
  };

  return (
    <Table
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table"
    >
      <TableHead style={{ width: '100%' }}>
        <TableRow className="table-header-row">
          {rows.map((row, i) => (
            <TableCell
              key={`${row.id}-${row.unique}-table-header-cell`}
              className="table-header-cell"
            >
              {i === 0 ? row.label : null}
            </TableCell>
          ))}
        </TableRow>
        <TableRow className="table-header-row">
          {rows.map((row, i) => {
            if (i === 0) return null;
            return (
              <TableCell
                key={`${row.id}-${row.unique}-table-header-cell`}
                className="table-header-cell"
              >
                {row.label}
              </TableCell>
            );
          })}
          <TableCell
            style={{
              padding: '4px 6px 4px 6px',
              fontSize: '11px',
              borderBottom: '1px solid black',
            }}
          />
        </TableRow>
      </TableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {patientData.length > 0 ? (
          patientData.map((n) => renderDataSet(n))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>
                <div className="alert alert-warning" role="alert">
                  Please enter correct Data and Search
                </div>
              </TableCell>
            </>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

UtilizationTable.defaultProps = {
  data: [],
  header: [],
};

UtilizationTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
};

export default UtilizationTable;
