import PropTypes from 'prop-types';
import React from 'react';
import AutoFillUtilization from './AutoFillUtilization';
import AutoFillSummary from './AutoFillSummary';
import AutoFillCancellation from './AutoFillCancellation';


const AutoFillUtilizationMain = (props) => {
  const { location } = props;
  const { search } = location;
  const params = new URLSearchParams(search);
  const reportType = params.get('reportType');

  switch (reportType) {
    case '1':
      return <AutoFillSummary {...props} />
    case '2':
      return <AutoFillUtilization {...props} />
    default:
      return <AutoFillCancellation {...props} />
  }
};

AutoFillUtilizationMain.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default AutoFillUtilizationMain;
