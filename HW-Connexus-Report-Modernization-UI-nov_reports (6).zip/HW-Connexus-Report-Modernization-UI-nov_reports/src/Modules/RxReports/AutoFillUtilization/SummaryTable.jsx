import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import React from 'react';
import '../../../assets/table.css';

const SummaryTable = ({ data: patientData, header: rows, totals }) => (
  <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
    <TableHead style={{ width: '100%' }}>
      <TableRow className="table-header-row">
        {rows.map(
          (row) => (
            <TableCell className="table-header-cell" key={row.id}>
              {row.label}
            </TableCell>
          ),
          this,
        )}
      </TableRow>
    </TableHead>
    <TableBody id="reportTableBody" className="report-table-body">
      {patientData.length > 0 ? (
        patientData.map((n, index) => (
          <TableRow
            id={`reportTableRow${index}`}
            hover
            tabIndex={-1}
            key={`${n.unique}-table-row`}
          >
            {rows.map(
              (row) => (
                <TableCell
                  key={`${n.unique} - ${row.id}`}
                  style={{
                    padding: '4px 6px 4px 6px',
                    fontSize: '11px',
                    borderBottom: '0px',
                  }}
                >
                  {n[row.id]}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
        ))
      ) : (
        <TableRow hover tabIndex={-1}>
          <>
            <TableCell colSpan={12}>
              <div className="alert alert-warning" role="alert">
                Please enter correct Data and Search
              </div>
            </TableCell>
          </>
        </TableRow>
      )}
      {/* Renders totals */}
      <TableRow
        hover
        tabIndex={-1}
        style={{ borderTop: '1px solid black' }}
        selected // Set to true for totals bar shading
      >
        {rows.map((row) => (
          // totals obj with k,v pairs that match header ids ensuring data is accurately mapped
          <TableCell
            key={`${row.id}-table-row-cell-totals`}
            style={{
              padding: '4px 6px 4px 6px',
              fontSize: '11px',
              borderBottom: '0px',
            }}
          >
            {row.id === 'date' ? <strong>Totals:</strong> : totals[row.id]}
          </TableCell>
        ))}
      </TableRow>
    </TableBody>
  </Table>
);

SummaryTable.defaultProps = {
  data: [],
  header: [],
  totals: {},
};

SummaryTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
  totals: PropTypes.objectOf(PropTypes.any),
};

export default SummaryTable;
