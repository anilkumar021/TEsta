import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <p>
        <Link to="/auto-fill-utilization?fromDate=10/6/2020 12:00:00 AM&toDate=11/6/2020 12:00:00 AM&sortBy=1&reportType=2&patientId=0&rxNumber=0&Connector= null">
          Auto Fill Utilization
        </Link>
      </p>
      <p>
        <Link to="/auto-fill-utilization?fromDate=10/6/2020 12:00:00 AM&toDate=11/6/2020 12:00:00 AM&sortBy=1&reportType=1&patientId=103088&rxNumber=0&Connector=AND">
          Auto Fill Utilization Summary
        </Link>
      </p>
      <p>
      <Link to="/auto-fill-utilization?fromDate=10/6/2020 12:00:00 AM&toDate=11/6/2020 12:00:00 AM&sortBy=1&reportType=3&patientId=103088&rxNumber=0&Connector=AND">
          Auto Fill Cancellation
        </Link>
      </p>
      <p>
        <Link to="/rx-report?rxNumber=2200203&fillDate=10/10/2020%2012:00:00%20AM&storeId=123">
          Rx-Report
        </Link>
      </p>
      <p>
        <Link to="/4-point-check-report?fromDate=10/22/2020%2012:00:00%20AM&toDate=10/22/2020%2012:00:00%20AM&storeId=123">
          4 Point Check Report
        </Link>
      </p>
      <p>
        <Link to="/pharmacy-activity?activityDate=10-23-2020 1:39:38 AM&userName=Sudheer Kumar">
          Pharmacist Activity
        </Link>
      </p>
      <p>
        <Link to="/controlled-substance-pickup-report?fromDate=8/24/2020 2:41:19 AM&patientID=114035&toDate=10/23/2020 2:41:19 AM&rxNumber=0&sortByDrug=True">
          Controlled Substance Pickup Report
        </Link>
      </p>
      <p>
        <Link to="/central-fill-performance-report?fromDate=9/23/2020 12:00:00 AM&toDate=10/23/2020 12:00:00 AM">
          Central Fill Performance Report
        </Link>
      </p>
      <p>
        <Link to="/drug-inventory-onhand?isSummaryReport=False&drugControlCodeOption=1&includeDiscontinued=False&includeActive=True&drugName=null&productMdsFamId=0&includeDaysSupplyPackMin=False&supplierId=0&sortOption=3&KioskInventory=False">
          Current On Hold Inventory Details
        </Link>
      </p>
      <p>
        <Link to="/drug-inventory-onhand?isSummaryReport=True&drugControlCodeOption=1&includeDiscontinued=False&includeActive=True&drugName=null&productMdsFamId=0&includeDaysSupplyPackMin=False&supplierId=0&sortOption=3&KioskInventory=False">
          Current On Hold Inventory Report Summary
        </Link>
      </p>
      <p>
        <Link to="/pharmacy-business-summary?startDate=9/23/2020 12:00:00 AM&endDate=10/23/2020 12:00:00 AM&reportType=MonthlyReport">
          Pharmacy Business Summary
        </Link>
      </p>
      <p>
        <Link to="/remote-order-review?fromDate=9/23/2020%2012:00:00%20AM&toDate=10/23/2020%2012:00:00%20AM">
          Remote Order Report
        </Link>
      </p>
      <p>
        <Link to="/leaflet-cover-sheet-printed-by-language?startSoldDate=9/23/2020 12:00:00 AM&endSOldDate=10/23/2020 12:00:00 AM">
          Leaflet Cover Sheet
        </Link>
      </p>
      <p>
        <Link to="/missed-opportunities-report?date=9/22/2020 12:00:00 AM">
          Missed Oppurtunities Report
        </Link>
      </p>
      <p>
        <Link to="/tp-receivables-by-reg-acct-159?fromDate=10/8/2020 12:00:00 AM&toDate=10/22/2020 12:00:00 AM">
          TP Receivables
        </Link>
      </p>
      <p>
        <Link to="/wait-for-drug?fromDate=10/4/2020%2012:00:00%20AM&toDate=11/4/2020%2012:00:00%20AM&sortOption=1">
          Wait For Drug Order
        </Link>
      </p>
      <p>
        <Link to="/partial-fill?fromDate=10/12/2020 12:00:00 AM&toDate=11/12/2020 12:00:00 AM&replayOut=1&sortOption=2">
          Partial Fill Report
        </Link>
      </p>
      <p>
        <Link to="/compliance?nextFillDate=11/14/2020 12:00:00 AM&productId=0&prescriberId=0&patientId=0&complianceIndex=N&showPatientIndex=Y&showPrescriberIndex=N&includeDeceasedPatientsData=false">
          Compliance Report
        </Link>
      </p>
      <p>
        <Link to="/hundred-days-drugs-not-used?warehouseItem=true&nonWarehouseItem=true&mickessonDrugCompany=true&amerisourcebergenCorporation=true">
          100 Days Drugs Not Used
        </Link>
      </p>

      <p>
        <Link to="/on-hold?fromDate=10/10/2020 12:00:00 AM&toDate=11/10/2020 12:00:00 AM">
          OnHold Report
        </Link>
      </p>
      <p>
        <Link to="/cancel-fill?fromDate=10/10/2020 12:00:00 AM&toDate=11/10/2020 12:00:00 AM&includeSystemCancel=False&sortByFillDate=True&sortByUserId=False&sortByCancelReason=False&getDataByFillDate=True&getDataByCancelDate=true">
          Cancel Fill
        </Link>
      </p>
      <p>
        <Link to="/bagging-detail?fromDate=11/20/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&userId =null&patientId=0&itemId=0&isSummaryReport=False&isDetailedReport=True&sortBy=User&storeId=5533">
          Bagging Detail Report
        </Link>
      </p>
      <p>
        <Link to="/bagging-detail?fromDate=11/20/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&userId =null&patientId=0&itemId=0&isSummaryReport=True&isDetailedReport=False&sortBy=User&storeId=5533">
          Bagging Summary Report
        </Link>
      </p>
      <p>
        <Link to="/will-call-bin?fromDate=11/6/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&isIncludeAll=False&patientId=103088&mdsFamId=148033&prescriberId=0&sortBy=Blank&excludeReadyReminderRxs=False&isCompound=False&isSummaryReport=False&isDetailedReport=True&sortLevel1=Patient&sortLevel2=Qty&sortLevel3=Color&storeId=5533">
          Will Call Bin Detail Report
        </Link>
      </p>
      <p>
        <Link to="/will-call-bin?fromDate=11/6/2020 12:00:00 AM&toDate=11/20/2020 12:00:00 AM&isIncludeAll=False&patientId=103088&mdsFamId=148033&prescriberId=0&sortBy=Blank&excludeReadyReminderRxs=False&isCompound=False&isSummaryReport=True&isDetailedReport=False&sortLevel1=Patient&sortLevel2=Qty&sortLevel3=Color&storeId=5533">
          Will Call Bin Summary Report
        </Link>
      </p>
      <p>
        <Link to="/cii-digital-logbook?fromDate=10/18/2019 12:00:00 AM&toDate=11/18/2020 12:00:00 AM&mdsfamid=12345&storeId=5533">
          CII Digital Logbook
        </Link>
      </p>
      <p>
        <Link to="/cycle-count?storeId=5533">Cycle Count Report</Link>
      </p>
      <p>
        <Link to="/replenishment-unavailable?storeId=5545&fromDate=10/18/2020 12:00:00 AM&toDate=11/18/2020 12:00:00 AM&includeRx=Y">
          Replenishment UnAvailable Report
        </Link>
      </p>
      <p>
        <Link to="/replenishment-available?storeId=5545&fromDate=10/18/2020 12:00:00 AM&toDate=11/18/2020 12:00:00 AM&includeRx=Y">
          Replenishment Available Report
        </Link>
      </p>  
      <p>
        <Link to="/regulatory-patient-profile?startFillDate=1/1/2019 12:00:00 AM&endFillDate=11/23/2020 12:00:00 AM&patientId=103088&cashPayRestInd=False&storeId=5533">
          Regulatory Patient Profile Report
        </Link>
      </p>
      <p>
        <Link to="/order-completion-performance?showDetail=true">Order Completion Performance</Link>
      </p>
      <p>
        <Link to="/order-completion-performance?showDetail=false">Order Completion Performance Summary</Link>
      </p>
    </div>
  );
}

export default Home;
