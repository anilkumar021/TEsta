import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import Table from '../Common/Table';
import PrintReport from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import { getApi } from '../Common/AxiosCalls';

/**
 * Pharmacist Activity report
 */
export class PharmacistActivity extends Component {
  /**
   * constructor
   * @param {object}    props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading shows the content if flag is false which mean done with load
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const activityDate = params.get('activityDate');
    const userName = params.get('userName');
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    const header = {};
    getApi(
      URL,
      { activityDate, userName },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    let tableOne = [];
    let tableTwo = [];
    if (data && data.data && data.data.length > 0) {
      data.data.forEach((datum, index) => {
        if (index % 2 === 0) {
          tableOne = [...tableOne, datum];
        } else {
          tableTwo = [...tableTwo, datum];
        }
      });
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">{`Report Date :${data.date}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <div className="report-params">
          <h5 className="para">{`Activity Date # :${data.storeId}`}</h5>
          <h5 className="para">{`Pharmacist :${data.date}`}</h5>
        </div>
        <Grid container spacing={24}>
          <Grid item xs={6}>
            <Table data={tableOne} header={data.header} />
          </Grid>
          <Grid item xs={6}>
            <Table data={tableTwo} header={data.header} />
          </Grid>
        </Grid>
        <Grid container spacing={24}>
          <Grid item xs={6}>
            <p className="signature-label">Signature : </p>
            <p className="signature-value" />
          </Grid>
        </Grid>
        <Grid container spacing={24}>
          <Grid item xs={6}>
            <p className="signature-label">Date :</p>
          </Grid>
        </Grid>
      </div>
    );
  }
}

PharmacistActivity.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintReport(PharmacistActivity);
