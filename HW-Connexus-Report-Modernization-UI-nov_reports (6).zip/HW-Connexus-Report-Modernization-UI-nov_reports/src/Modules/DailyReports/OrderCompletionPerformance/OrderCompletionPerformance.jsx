import React, { Component } from 'react';
import { Grid } from '@material-ui/core';
import Table from '../../Common/Table';
import PrintWrapper from '../../Common/PrintReport';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from "../../Common/AxiosCalls";
import Summary from "./Summary";

/**
 * Controlled Substance Pickup Component
 */
export class OrderCompletionPerformance extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
      * @type {object}
      * @property {list} data Handle a list of data which return from server side
      * @property {boolean} loading Will show the content if loading is false which mean done with load
      * @property {string} error Handle error Message
      */
    this.state = {
      data: null,
      loading: true,
      error: null,
      showDetail: null
    };
  }
  /**
     * componentDidMount
     * @desc life cycle method for making Api call
  */
  componentDidMount() {
    const { location } = this.props;
    const { search } = location;
    const params = new URLSearchParams(search);
    this.setState({
      showDetail: params.get('showDetail')
    })

    getApi('order-completion-performance.json', {}, {}, (res) => {
      this.setState({ data: res.data, loading: false, error: null })
    }, (err) => {
      this.setState({ data: null, error: err, loading: false })
    });
  }
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return (
        <div>
          Error :{error}
        </div>
      );
    }
    return (
      <div className="report-container">
        <Grid container spacing={3} justify="space-between">
          <Grid item xs>
            <p className="para">
              Store # :
              {data.storeId}
            </p>
            <p className="para">
              Report Date :
              {data.reportDate}
            </p>
            <br />
            <p className="para">
              from :
              {data.startDate + " "}
              To:
              {" " + data.reportDate}
            </p>
          </Grid>
          <Grid item xs>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs>
            <p className="para">{data.reportDate}</p>
            <p className="para">{data.address}</p>
            <p className="para">{data.detail}</p>
          </Grid>
        </Grid>
        {this.state.showDetail === "true" ? (
          <Table
            data={data.data}
            header={data.header}
          />
        ) : (
            <p className="divider-line" />
          )
        }
        <Summary data={data.summary} />
      </div>
    );
  }
}

export default PrintWrapper(OrderCompletionPerformance);