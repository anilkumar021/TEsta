import React, { Component } from 'react';
import { Grid } from '@material-ui/core';

export default class Summary extends Component {
    render() {
        const { data: summary } = this.props;
        return (
            <div>
                <h3>Grand Total</h3>
                <p className="divider-line" />
                <Grid container spacing={3} >
                    <Grid item xs={4}>
                        <h4 className="pharma-header">% Patient Expectation Met:</h4>
                        <p className="para">Total Order</p>
                        <p className="para">Total RXS</p>
                        <p className="para">% Order went throgh RES</p>
                        <p className="para">% RX went through RES</p>
                        <p className="para">% Order 'Instore/First Available:</p>
                        <p className="para">Average 'Instore/First Available' System Calculation(minutes):</p>
                        <p className="para">Average 'Instore/First Available' Order Performance(minute):</p>
                        <p className="para">Average 'Instore/First Available' Order Performance including RES(minute):</p>
                        <p className="para">Total Orders On Time/Under Due:</p>
                        <p className="para">% Orders 'Instore/First Available' On Time</p>
                        <p className="para">% Orders 'Instore/First Available' On Time including RES:</p>
                        <p className="para">% Orders 'Drive Thru' On Time:</p>
                        <p className="para">% Orders 'Today' (excluding 'First Available') On Time:</p>
                        <p className="para">% Orders 'Critical' On Time:</p>
                        <p className="para">% Orders 'Dr Call In' On Time:</p>
                        <p className="para">% Orders 'Future' On Time:</p>
                        <p className="para">Avg Minutes Over Due Time:</p>
                        <p className="para">Avg Minutes Under Due Time:</p>
                        <p className="para">% Orders Due Time Modified</p>
                        <p className="para">Due Time Modified By User ID</p>
                    </Grid>
                    <Grid item xs={4}>
                        <p className="para">{summary.petientExpect.toFixed(2)}</p>
                        <p className="para">{summary.totalorder}</p>
                        <p className="para">{summary.totalRxs}</p>
                        <p className="para">{summary.orderRes.toFixed(2)}</p>
                        <p className="para">{summary.rxRes.toFixed(2)}</p>
                        <p className="para">{summary.firstAvailable.toFixed(2)}</p>
                        <p className="para">{summary.sysCal.toFixed(2)}</p>
                        <p className="para">{summary.orderPerformance.toFixed(2)}</p>
                        <p className="para">{summary.orderPerformanceRes.toFixed(2)}</p>
                        <p className="para">{summary.underDue.toFixed(2)}</p>
                        <p className="para">{summary.ontime.toFixed(2)}</p>
                        <p className="para">{summary.ontimeRes.toFixed(2)}</p>
                        <p className="para">{summary.drivethruOnTime.toFixed(2)}</p>
                        <p className="para">{summary.todayOnTimeRes.toFixed(2)}</p>
                        <p className="para">{summary.criticalOnTime.toFixed(2)}</p>
                        <p className="para">{summary.drcallinOneTime.toFixed(2)}</p>
                        <p className="para">{summary.futureOnTime.toFixed(2)}</p>
                        <p className="para">{summary.overDueTime}</p>
                        <p className="para">{summary.underDueTime}</p>
                        <p className="para">{summary.timeModified}</p>
                        {summary.userId.map((n, index) => (
                            <p className="para">{n.userId}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{n.num}</p>
                        ))}
                    </Grid>
                </Grid>
            </div>
        )
    }

}