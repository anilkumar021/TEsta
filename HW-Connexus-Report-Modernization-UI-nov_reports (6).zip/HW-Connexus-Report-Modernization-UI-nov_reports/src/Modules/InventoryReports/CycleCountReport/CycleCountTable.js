import React from 'react';
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  Container,
  TextField,
} from '@material-ui/core';
import PropTypes from 'prop-types';
import '../../../assets/table.css';

const CycleCountTable = ({ data: patientData, header: rows }) => {
  return (
    <Container
      maxWidth="xl"
      disableGutters
      className="cycle-count-table"
    >
      <Table
        aria-labelledby="tableTitle"
        id="reportTable"
        className="report-table"
      >
        <TableHead style={{ width: '100%' }}>
          <TableRow className="table-header-row">
            {rows.map((row) => (
              <TableCell className="table-header-cell" key={row.id}>
                {row.label}
              </TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody id="reportTableBody" className="report-table-body">
          {patientData.length > 0 ? (
            patientData.map((n, index) => (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={n.unique}
              >
                {rows.map(
                  (row) => (
                    <TableCell
                      key={row.id}
                      style={{
                        padding: '4px 6px 4px 6px',
                        fontSize: '11px',
                        borderBottom: '0px',
                      }}
                    >
                      {row.id === 'enterQuantity' ? (
                        <TextField
                          type="number"
                          id={`enterQuantity${index}`}
                          variant="outlined"
                          size="small"
                        />
                      ) : (
                        n[row.id]
                      )}
                    </TableCell>
                  ),
                  this,
                )}
              </TableRow>
            ))
          ) : (
            <TableRow hover tabIndex={-1}>
              <>
                <TableCell colSpan={12}>
                  <div className="alert alert-warning" role="alert">
                    No Record Found
                  </div>
                </TableCell>
              </>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </Container>
  );
};

CycleCountTable.defaultProps = {
  data: [],
  header: [],
};

CycleCountTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
};

export default CycleCountTable;
