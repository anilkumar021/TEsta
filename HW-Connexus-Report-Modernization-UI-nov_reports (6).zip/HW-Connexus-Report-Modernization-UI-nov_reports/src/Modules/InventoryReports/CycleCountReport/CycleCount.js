import React, { Component } from 'react';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../../Common/PrintReport';
import CycleCountTable from './CycleCountTable';
import { API_URL, getConfig } from '../../../settings';
import { getApi } from '../../Common/AxiosCalls';
import './CycleCount.css';

/**
 * CycleCount Component
 */
export class CycleCount extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false - finished loading
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const key = pathname.substr(1);
    const header = {};
    const URL = `${getConfig(key).substr(1)}.json`;

    getApi(
      URL,
      { params },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    const { location = {} } = this.props;
    const { search } = location;
    const params = new URLSearchParams(search);
    const storeId = params.get('storeId');

    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={0}>
          <Grid item xs={4}>
            <p className="para">{`Store # : ${storeId}`}</p>
            <p className="para">
              {`Report Date :${
                data.reportDate ? data.reportDate : ''
              }`}
            </p>
            <br />
            <p className="para">{data.dateRange}</p>
          </Grid>
          <Grid item xs={4} className="text-center">
            <h4 className="pharma-header">{data.appName}</h4>
            <h4 className="pharma-header">{data.store}</h4>
            <h4 className="pharma-header">{data.reportName}</h4>
          </Grid>
        </Grid>
        <br />
        <CycleCountTable data={data.data} header={data.header} />
        <h5 className="text-center">{data.note}</h5>
      </div>
    );
  }
}
export default PrintWrapper(CycleCount);
