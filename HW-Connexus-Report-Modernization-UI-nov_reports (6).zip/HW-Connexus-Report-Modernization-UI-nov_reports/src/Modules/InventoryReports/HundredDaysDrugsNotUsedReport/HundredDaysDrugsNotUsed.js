import React, { Component } from 'react';
import { Grid } from '@material-ui/core';

import Table from '../../Common/Table';
import { getApi } from '../../Common/AxiosCalls';
import PrintWrapper from '../../Common/PrintReport';

/**
 * HundredDaysDrugsNotUsed Component
 */
export class HundredDaysDrugsNotUsed extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {list} data Handle a list of data which return from server side
     * @property {boolean} loading Will show the content if loading is false - finished loading
     * @property {string} error Handle error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    getApi(
      '100-days-drugs-not-used.json',
      {},
      {},
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement}  content for this component
   */
  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store # :${data.storeId}`}</p>
            <p className="para">
              {`Report Date :${data.reportDate}`}
            </p>
            <br />
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
        </Grid>
        <p className="divider-line" />
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <h5 className="pharma-header">Supplier:</h5>
            <br />
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.supplier}</h5>
          </Grid>
        </Grid>
        <br />
        <Table
          data={data.data.data1}
          header={data.header1}
          bodyClassName=""
        />
        <Table data={data.data.data2} header={data.header2} />
      </div>
    );
  }
}
export default PrintWrapper(HundredDaysDrugsNotUsed);
