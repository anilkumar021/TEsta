import React, { Component } from 'react';
import { Grid } from '@material-ui/core';
import PrintWrapper from '../Common/PrintReport';
import Table from '../Common/Table';
import { getApi } from '../Common/AxiosCalls';
import { API_URL, getConfig } from '../../settings';
/**
 * Regulatory Patient Profile Report Component
 */

export class RegulatoryPatientProfileReport extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */

  componentDidMount() {
    // getApi(
    //   'regulatory-patient-profile-report.json',
    //   {},
    //   {},
    //   ({ data }) => {
    //     this.setState({ data, loading: false, error: null });
    //   },
    //   (err) => {
    //     this.setState({ data: null, error: err, loading: false });
    //   },
    // );

    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const startFillDate = params.get('startFillDate');
    const endFillDate = params.get('endFillDate');
    const patientId = params.get('patientId');
    const cashPayRestInd = params.get('cashPayRestInd');
    const storeId = params.get('storeId');
    const header = {};
    const key = pathname.substr(1);
    const URL = API_URL + getConfig(key);
    getApi(
      URL,
      { startFillDate, endFillDate, patientId,cashPayRestInd,storeId },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement} markup
   */

  render() {
    const { data, loading, error } = this.state;
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{error}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={24}>
          <Grid item xs={4}>
            <p className="para">{`Store #: ${data.storeNumber}`}</p>
            <p className="para">{`Report Date: ${data.reportDate}`}</p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
        </Grid>
        <p className="divider-line" />
        <Grid container spacing={24}>
          <Grid item xs={1}>
            <h5 className="pharma-header">Patient:</h5>
          </Grid>
          <Grid item xs={1}>
            <p className="pharma-header">{data.patient}</p>
          </Grid>
        </Grid>
        <br />
        <Grid container spacing={24}>
          <Grid item xs={1}>
            <h5 className="para">BirthDate:</h5>
          </Grid>
          <Grid item xs={1}>
            <p className="pharma-header">{data.birthDate}</p>
          </Grid>
        </Grid>
        <p className="divider-line" />
        <p className="para">{`Below is a list of your Pharmacy Orders for the date range of : ${data.from} To ${data.to}`}</p>
        <br />
        <Table data={data.data} header={data.header} />
        <h5>{data.note}</h5>
      </div>
    );
  }
}
// npx eslint src/
/**
 * propTypes
 * @property {object} location windows location object
 */
export default PrintWrapper(RegulatoryPatientProfileReport);
