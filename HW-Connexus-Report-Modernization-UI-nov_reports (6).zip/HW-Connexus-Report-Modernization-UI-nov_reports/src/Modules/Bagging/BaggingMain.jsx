import PropTypes from 'prop-types';
import React from 'react';
import BaggingDetail from './BaggingDetail';
import BaggingSummary from './BaggingSummary';

/**
 * Will call the Bagging summary or bagging detail depend on the parameter.
 * @param {Params} props  Params
 */
const BaggingMain = (props) => {
  const { location } = props;
  const { search } = location;
  const params = new URLSearchParams(search);
  const isSummaryReport = params.get('isSummaryReport');

  return isSummaryReport === 'True' ? (
    <BaggingSummary {...props} />
  ) : (
      <BaggingDetail {...props} />
    );
};

BaggingMain.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default BaggingMain;