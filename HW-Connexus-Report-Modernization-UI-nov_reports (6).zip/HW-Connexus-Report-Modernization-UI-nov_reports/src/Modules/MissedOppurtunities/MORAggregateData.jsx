import React from 'react'


export class MORAggregateData extends React.Component{

      render(){
        const { data } = this.props;
          return(
                <div>
                    <div className="bottom-border">
                        <div className="data_row">
                            <p>{`Total Multi-Source Code O: ${ data.totalCountO}`} </p>
                        </div>
                        <div className="data_row">
                            <p>{`Total Multi-Source Code Y: ${ data.totalCountY}`}</p>
                            
                        </div>
                        <div className="data_row">
                            <p>{`Total Multi-Source Code Y and O: ${data.totalCountOY}` }</p>
                           
                        </div>
                        <div className="data_row">
                            <p>{`Total Multi-Source Code O and DAW 1: ${data.mscOOfDaw1}`} </p>
                            
                        </div>
                        <div className="data_row">
                            <p>{`Total Multi-Source Code Y and less DAW code 1: ${ data.mscOYNoDaw1}`}</p>
                        </div>
                    </div>
                    <br></br>
                                        <div id="part2">
                        <p>Generic Substitution Percent of Multi-Source Code O: </p>
                        <p>{data.genSubO}</p>
                        <p>Generic Substitution Percent of Multi-Source Code O Less DAW Code 1 Transactions:</p>
                        <p>{data.genDobOnDaw}</p>
                    </div>

                </div>
          );
          
      }
}