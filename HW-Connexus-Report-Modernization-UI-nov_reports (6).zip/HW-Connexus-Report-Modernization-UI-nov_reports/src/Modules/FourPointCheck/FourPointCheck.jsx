import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Grid } from '@material-ui/core';
import moment from 'moment';
import Table from './Table';
import PrintWrapper from '../Common/PrintReport';
import { API_URL, getConfig } from '../../settings';
import { getApi } from '../Common/AxiosCalls';
/**
 * FourPointCheck Component
 */
export class FourPointCheck extends Component {
  /**
   * constructor
   * @param {object} props
   */
  constructor(props) {
    super(props);
    /**
     * @type {object}
     * @property {object} data Input Data
     * @property {boolean} loading Loading Flag
     * @property {string} error Error Message
     */
    this.state = {
      data: null,
      loading: true,
      error: null,
    };
  }

  /**
   * componentDidMount
   * @desc life cycle method for making Api call
   */
  componentDidMount() {
    const { location } = this.props;
    const { search, pathname = '' } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const key = pathname.substr(1);
    const header = {};
    const URL = API_URL + getConfig(key);

    getApi(
      URL,
      { fromDate, toDate },
      header,
      (res) => {
        this.setState({
          data: res.data,
          loading: false,
          error: null,
        });
      },
      (err) => {
        this.setState({ data: null, error: err, loading: false });
      },
    );
  }

  /**
   * render
   * @return {ReactElement} markup
   */
  render() {
    const { data, loading, error } = this.state;
    const { location = {} } = this.props;
    const { search } = location;
    const params = new URLSearchParams(search);
    const fromDate = params.get('fromDate');
    const toDate = params.get('toDate');
    const storeId = params.get('storeId');
    if (loading) {
      return <div>Loading ....</div>;
    }
    if (error) {
      return <div>{`Error :${error}`}</div>;
    }
    return (
      <div className="report-container">
        <Grid container spacing={4}>
          <Grid item xs={4}>
            <p className="para">{`Store # : ${storeId}`}</p>
            <p className="para">
              {`Report Date : ${moment().format('MM/DD/YYYY')}`}
            </p>
          </Grid>
          <Grid item xs={4}>
            <h5 className="pharma-header">{data.appName}</h5>
            <h5 className="pharma-header">{data.store}</h5>
            <h5 className="pharma-header">{data.reportName}</h5>
          </Grid>
          <Grid item xs={4}>
            <p className="para">{data.details}</p>
          </Grid>
        </Grid>
        <p className="divider-line" />
        <p className="para">
          {` 
          From : ${moment(fromDate, 'MM/DD/YYYY').format(
            'MM/DD/YYYY',
          )} 
          To : ${moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY')}`}
        </p>
        <p className="divider-line" />
        <div>
          {data.dates && data.dates.length === 0 && (
            <p className="empty-table-body">No Records Found</p>
          )}
          {data.dates &&
            data.dates.length > 0 &&
            data.dates.map((datum) => {
              let count = 0;
              return (
                <div key={datum.date}>
                  <h5 className="pharma-header">
                    {` 
                    Date: ${datum.date}`}
                  </h5>
                  {datum.pharmacists.length === 0 ? (
                    <Table
                      data={datum.pharmacists}
                      header={data.header}
                    />
                  ) : (
                    datum.pharmacists.map((pharmacists, index) => {
                      count += pharmacists.data.length;
                      return (
                        <div key={pharmacists.pharmacistName}>
                          <h5 className="pharma-header">
                            {`Pharmacist : ${pharmacists.pharmacistName}`}
                          </h5>
                          <Table
                            data={pharmacists.data}
                            header={data.header}
                          />
                          <h5 className="pharma-header">
                            {`Total 4Point Check done by 
                            ${pharmacists.pharmacistName} 
                            ${pharmacists.data.length}`}
                          </h5>
                          {datum.pharmacists.length === index + 1 && (
                            <h5 className="pharma-header">
                              {`Total 4Point Check done on ${datum.date} 
                              ${count}`}
                            </h5>
                          )}
                          <p className="divider-line" />
                        </div>
                      );
                    })
                  )}
                </div>
              );
            })}
        </div>
        <h6>{data.note}</h6>
      </div>
    );
  }
}

/**
 * propTypes
 * @property {object} location windows location object
 */
FourPointCheck.propTypes = {
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PrintWrapper(FourPointCheck);
