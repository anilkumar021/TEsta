import React from 'react';
import PropTypes from 'prop-types';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../assets/table.css';

const CustomTable = ({ data: patientData, header: rows }) => {
  return !patientData ? (
    <h3> NO DATA FOUND </h3>
  ) : (
    <Table
      aria-labelledby="tableTitle"
      id="reportTable"
      className="report-table"
    >
      <TableHead style={{ width: '100%' }}>
        <TableRow className="table-header-row">
          {rows.map((row) => (
            <TableCell className="table-header-cell" key={row.id}>
              {row.label}
            </TableCell>
          ))}
        </TableRow>
      </TableHead>
      <TableBody id="reportTableBody" className="report-table-body">
        {patientData ? (
          patientData.map((n) => (
            <TableRow
              id={`reportTableRow${n.userId}`}
              hover
              tabIndex={-1}
              key={`reportTableRow${n.userId}`}
            >
              {rows.map((row) => (
                <TableCell
                  key={`reportTableRow${n[row.id]}`}
                  style={{
                    padding: '4px 6px 4px 6px',
                    fontSize: '11px',
                    borderBottom: '0px',
                    width: '12.5%',
                  }}
                >
                  {n[row.id]}
                </TableCell>
              ))}
            </TableRow>
          ))
        ) : (
          <TableRow hover tabIndex={-1}>
            <>
              <TableCell colSpan={12}>No Records Found</TableCell>
            </>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

CustomTable.defaultProps = {
  data: [],
  header: [],
};

CustomTable.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  header: PropTypes.arrayOf(PropTypes.object),
};

export default CustomTable;
