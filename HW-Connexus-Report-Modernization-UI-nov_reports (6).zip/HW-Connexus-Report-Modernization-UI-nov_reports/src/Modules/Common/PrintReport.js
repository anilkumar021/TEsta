import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import { Button, ButtonGroup } from '@material-ui/core';
import { withRouter } from 'react-router-dom';

export default (WrapperComponent) =>
  class extends Component {
    render() {
      const Comp = withRouter(WrapperComponent);
      return (
        <div>
          <ReactToPrint
            trigger={() => (
              <div className="button-container">
                <ButtonGroup
                  variant="contained"
                  color="primary"
                  aria-label="contained primary button group"
                >
                  <Button style={{ fontSize: '10px' }}>Print</Button>
                </ButtonGroup>
              </div>
            )}
            content={() => this.componentRef}
          />
          <div
            ref={(el) => {
              this.componentRef = el;
            }}
          >
            <Comp {...this.props} />
          </div>
        </div>
      );
    }
  };
