import React from 'react';

const Loader = () => <div>Loading ....</div>;

export default Loader;
