/**
 * @desc class for testing/logging latency
 * @method start - logs the start time of a latency test
 * @method end - logs the end time and time taken of a latency test
 */
export default class LatencyTest {
  constructor(label) {
    this.label = label;
  }

  /**
   * @desc method logs the start time of a latency test
   * @param {string} description - description for log
   */
  start(description) {
    this.startTime = new Date();
    console.log(
      `${this.label} ${description} ${LatencyTest.parseTime(
        this.startTime,
      )}`,
    );
  }

  /**
   * @desc method logs the end time and time taken of a latency test
   * @param {string} description - description for log
   */
  end(description) {
    this.endTime = new Date();
    console.log(
      `${this.label} ${description} ${LatencyTest.parseTime(
        this.endTime,
      )}`,
    );

    console.log(
      `${this.label} time taken:${
        this.endTime.getTime() - this.startTime.getTime()
      }ms`,
    );
  }

  /**
   * @desc method for formatting date and time
   * @param {object} dateObj - instance of Date (current date/time)
   * @return {string} formatted date and time
   */
  static parseTime(dateObj) {
    const [month, date, year] = dateObj
      .toLocaleDateString('en-US')
      .split('/');
    const [hour, minute, second] = dateObj
      .toLocaleTimeString('en-US', { hour12: false })
      .split(/:| /);
    const milliSecond = dateObj.getMilliseconds();

    return `${month}:${date}:${year} ${hour}:${minute}:${second}:${milliSecond}`;
  }
}

// Output
// API Test: Request Sent: 11:17:2020 13:42:36:36
// API Test: Response Received: 11:17:2020 13:42:36:95
// API Test: time taken:59ms

/*
 * Instructions:
 *
 * Import default class into the file you are working on.
 * Instantiate a new LatencyTest object with string label.
 * Call obj.start('Request Sent:') before api call.
 * Call obj.end('Response Received:') after api call promise returns response in the .then() block.
 *
 * Example:
 *
 * // Latency Test - INSTANTIATION
 * const test = new LatencyTest('API Test:');
 *
 * // Latency Test - START
 * test.start('Request Sent:');
 *
 * axios.get(url...)
 *   .then((some data) => {
 *
 *   // Latency Test - END
 *   test.end('Response Received:');
 *
 *   })
 *   .catch(error) => error...
 */
