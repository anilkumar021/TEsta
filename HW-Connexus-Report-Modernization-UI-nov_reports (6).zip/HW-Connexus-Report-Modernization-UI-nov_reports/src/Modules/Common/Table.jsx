import React, { Component, Fragment } from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import '../../assets/table.css';

export default class CustomTable extends Component {
  render() {
    const { data: patientData, header: rows, footer, bodyClassName } = this.props;
    return (
      <Table aria-labelledby="tableTitle" id="reportTable" className="report-table">
        <TableHead style={{ width: '100%' }}>
          <TableRow className="table-header-row" >
            {rows.map(
              (row) => (
                <TableCell
                  className="table-header-cell"
                  style={{lineHeight:'24px'}}
                  key={row.id}
                >
                  {row.label}
                </TableCell>
              ),
              this,
            )}
          </TableRow>
        </TableHead>
        <TableBody id="reportTableBody" className={bodyClassName}>
          {patientData.length > 0 ? (
            patientData.map((n, index) => (
              <TableRow
                id={`reportTableRow${index}`}
                hover
                tabIndex={-1}
                key={n.unique}
              >
                {rows.map(
                  (row) => (
                    <TableCell key={n.unique + n[row.id]} style={{ padding: '4px 6px 4px 6px', fontSize: '11px', borderBottom: '0px' }}>{n[row.id]}</TableCell>
                  ),
                  this,
                )}
              </TableRow>

            ))
          ) : (
              <TableRow
                hover
                tabIndex={-1}
                className="empty-table-row"
              >
                <Fragment>
                  <TableCell colSpan={12} className="empty-table-body">
                    No Records Found
                  </TableCell>
                </Fragment>
              </TableRow>
            )}
        </TableBody>
        {footer}
      </Table>
    );
  }
}

CustomTable.defaultProps = {
  footer: null,
  bodyClassName: "report-table-body"
}
